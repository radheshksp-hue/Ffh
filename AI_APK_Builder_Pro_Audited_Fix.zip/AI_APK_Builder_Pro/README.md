# AI APK Builder Pro

**Upload. Analyze. Build. Fix. Download.**

A native Android (Kotlin + Jetpack Compose) personal-testing tool that selects an Android Studio ZIP from phone storage, extracts it into app-private storage with ZIP-safety checks, analyzes the Gradle project, uploads a normalized source ZIP as an asset in a verified **private GitHub Release**, tracks the exact GitHub Actions run, retrieves diagnostic artifacts, optionally asks Gemini to diagnose a real failure, validates a proposed patch against the original file hash, and downloads verified APK artifacts.

> **Delivery state:** substantial source project and workflow included. The source archive is not represented as already compiled. The coding container had Java but no Android SDK, no installed Gradle executable, and no network DNS to fetch Gradle/dependencies, so an Android APK build and dependency-resolved compilation could not be run here. The official `gradle-wrapper.jar` is deliberately **not fabricated**. The included `gradlew` is a SHA-256-checking Gradle-distribution bootstrap launcher, not the official Wrapper; see “Wrapper status” below. The GitHub workflow defaults to requiring the official wrapper. It also includes a narrowly scoped, explicit opt-in fallback for a directly detected Android Gradle Plugin 8.13.2 project, using Gradle 8.13 only after SHA-256 verification. Real GitHub and Gemini end-to-end operations are **NOT TESTED** until you configure your own credentials and services.

## Features implemented in source

- Native Material 3 Compose UI, light/dark theme, navigation for Home, New Project, My Projects, History, AI Error Fixer, GitHub, Gemini, Logs, Downloads, Privacy, and Help.
- Android Storage Access Framework file picker and save dialogs; no broad storage permission.
- Streaming 100 MB ZIP input cap; app-private workspace; entry, path traversal, symlink, duplicate path, per-entry size, total expanded size, and depth checks.
- Project-root scoring with support for nested top-level folders; static Gradle/module/SDK manifest analysis.
- Source packaging that excludes common build caches, `.git`, local SDK paths, detected signing keys and files containing common secret patterns; exclusion preview; separate original ZIP and working copy.
- Room project/build history, Android Keystore AES-GCM encrypted GitHub/Gemini credentials, background status recovery worker.
- GitHub REST connection/privacy/permission checks, workflow comparison and confirmed replacement, draft Release creation, streamed raw ZIP asset upload, remote asset size verification, publication, exact tag-based run polling, artifacts/log retrieval, cancellation and cleanup.
- Included release-triggered workflow with tag-prefix guard, Java setup, safe ZIP validation, dynamic project-root detection, Gradle build task override, APK discovery, SHA-256, diagnostics even on failures, and bounded artifact retention.
- Gemini REST API test, supported model list, model ID setting, classified API failures, logs-only or consented source-context diagnosis, JSON repair proposals.
- Patch validation for normalized relative path, allowed extension, original SHA-256, stale-source detection, size caps, sensitive/workflow paths, and low-risk automatic-repair gating. Original project ZIP/workspace is retained while repairs use a separate working copy.
- Unit-test sources, valid/broken project fixtures, malformed ZIP and ZIP-slip fixtures, plus a dependency-free local static validator.

## Requirements

- Android Studio current enough for Android Gradle Plugin 8.13.x, JDK 17, and Android SDK Platform 36.
- An Android 8.0 (API 26) or newer phone/emulator.
- A **dedicated private GitHub repository** used only for this builder workflow and temporary uploaded Release assets.
- A fine-grained GitHub Personal Access Token scoped to that single repository.
- Optional Google Gemini API key. Model and account availability may vary; the model selector can fetch models advertising `generateContent` support.
- Internet access from the phone, and GitHub Actions enabled on the repository.

## Open and build the Android app

1. Extract the `AI_APK_Builder_Pro_Source.zip` source archive.
2. Open the `ai-apk-builder-pro` folder in Android Studio.
3. Set Android Studio's Gradle JDK to JDK 17. Install Android SDK Platform 36 when prompted.
4. Wait for Android Studio to resolve the Android Gradle Plugin and other dependencies. The first sync requires internet.
5. Use **Build → Make Project**, then run `app` on an API 26+ emulator/device.
6. To create an installable debug APK, use **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Do not treat a source build task or this README as evidence of a successful compile; verify the IDE's build output.

### Wrapper status and restoring the official wrapper

The build environment used to generate this archive had no Gradle installation and could not resolve external hosts. As a result, no authentic `gradle-wrapper.jar` could be downloaded or generated here. The included `gradlew`/`gradlew.bat` bootstrap downloads Gradle 8.13 and checks the distribution's published SHA-256 before running it. This is **not** the standard Gradle Wrapper and should be replaced by the official wrapper on a connected machine before treating the project as production-ready.

From the project root on a connected computer with Java 17+ and `curl`/`unzip` (or the Windows PowerShell bootstrap), run:

```bash
./gradlew wrapper --gradle-version 8.13 --distribution-type bin
```

Then verify that `gradle/wrapper/gradle-wrapper.jar` was created, inspect the generated scripts, and commit all official wrapper files. If you have a system Gradle already installed, the equivalent command is:

```bash
gradle wrapper --gradle-version 8.13 --distribution-type bin
```

The bootstrap launcher only supports Gradle 8.13, selected to match the project's AGP 8.13.x setup. It is a bootstrap utility rather than a verified official wrapper, and has not been network-tested in this offline environment. For the hosted workflow only, a reviewed fallback may be explicitly enabled with the repository Actions **variable** `APK_ALLOW_GRADLE_FALLBACK=true`. The current fallback refuses anything except a directly pinned AGP `8.13.2` and downloads Gradle `8.13` only after checking the published SHA-256. Default behavior remains off; add the official wrapper whenever possible.

## Configure the private GitHub builder repository

1. On GitHub, create a dedicated **private** repository, for example `your-user/apk-builder-private`. Do not use an unrelated application repository. Enable Actions in Settings → Actions → General.
2. Create a fine-grained token limited to this repository. Start with Repository permissions:
   - **Metadata: Read-only** (GitHub required repository metadata permission).
   - **Contents: Read and write** (Release creation/assets, source ZIP upload, release/tag cleanup, workflow file content endpoint).
   - **Actions: Read-only** (workflow runs, jobs, artifacts, logs and Actions settings check).
   - **Workflows: Read and write** may be required to create/update `.github/workflows/build-apk.yml`, depending on GitHub's token endpoint enforcement.
3. Enable repository Actions. If a token endpoint returns 403, use the exact missing-permission message and GitHub's current token-permission reference to add only that permission. Do not broaden the token to all repositories.
4. Install the app and open **GitHub Settings**. Fill in owner, repository, default branch and token. Tap **Test Connection & Save**. A public repository is rejected by this app.
5. Tap **Verify Repository Permissions**, **Verify GitHub Actions Availability**, and **Install / Verify Build Workflow**. If a different workflow is present, keep it or explicitly confirm replacement.
6. The root `.github/workflows/build-apk.yml` builds this AI APK Builder Pro repository on push or manual dispatch. The separate release-triggered builder-service workflow template is bundled at `app/src/main/assets/templates/build-apk.yml` for in-app installation into the dedicated private repository used to build user-uploaded project ZIPs.

The app checks for a private repository and push access before it can publish source releases. Tokens are stored in an AES-GCM encrypted blob backed by Android Keystore. This does not turn a client-side token into a server-side vault: a compromised/rooted device can still expose app secrets, and `android:allowBackup="false"` only disables Android app backup. Do not use this personal-testing architecture as-is for a public multi-user product. Move provider tokens to a backend or use a suitably implemented GitHub App/OAuth architecture before public distribution.

## Configure Gemini (optional)

1. Obtain an API key through Google's official Gemini API instructions: <https://ai.google.dev/gemini-api/docs/api-key>.
2. Open **Gemini Settings**. Enter the key and model ID and tap **Fetch Available Models** to see what your key currently exposes.
3. Choose a listed model and tap **Test API & Save**. The app makes a genuine `generateContent` request using the `x-goog-api-key` header, not a query parameter.
4. Builds remain available if Gemini is skipped or its quota is exhausted.
5. In AI Error Fixer, choose **logs only** or explicitly consent to send selected relevant source snippets. The entire ZIP is not sent to Gemini by default. Credentials and common secret patterns are redacted, but redaction is heuristic and cannot guarantee identification of every secret.

Google model IDs, quotas, pricing, eligibility for the free tier, and data-use policies can change; re-check the official documentation before choosing a model or sending sensitive source. Never assume “free” means unlimited or that submitted data will never be retained/used according to the provider's terms.

## Build an APK from your phone

1. Create a ZIP from the existing Android Studio project. Include project source/configuration and a valid `gradlew`, `gradle/wrapper/gradle-wrapper.jar`, and wrapper properties. Do not include your release keystore, signing password, `.env`, service account keys, or other credentials.
2. In AI APK Builder Pro tap **Upload Project ZIP** and select the ZIP with Android's file picker.
3. Tap **Extract & Analyze**. The app rejects unsafe/corrupted archives, detects nested project roots and presents an actual static report.
4. Review the project summary and all paths excluded from the upload package. The original ZIP is locally preserved and the build uses a separate working copy.
5. Open GitHub settings and verify connection, permissions, workflow and Actions availability.
6. Tap **Prepare Build ZIP**, review exclusions, then **Confirm & Upload Build**.
7. The app creates a unique `apkbuild-...-attempt-N` draft Release, uploads `project-source.zip` as binary data, verifies asset ID/name/size, then publishes the Release. The publishing event triggers the workflow. Do not create duplicate tags/builds merely because the UI temporarily has no run ID.
8. Open **Logs & Diagnostics** to view the live state pulled from the matching GitHub Actions run. The status follows the actual remote run and its job steps; network polling can time out while the remote job keeps running.
9. If a build fails, review the real diagnostic log. Configure Gemini and consent as desired, then tap **AI Diagnosis**. Review the proposed changes and diff. Safe Repair mode requires approval; Auto Fix only admits the narrow, high-confidence Kotlin/Java update rules in the validator and still depends on the subsequent real rebuild.
10. When artifacts are ready, open **Downloads**, choose the actual APK if multiple were produced, save through Android's document interface, and let the app verify size and SHA-256. The reported artifact is a **debug** APK unless you separately configured a legitimate release-signing pipeline.

## Workflow behavior and build task override

The root workflow builds this repository on `push` and `workflow_dispatch`. It checks the standard project root and manifest paths, configures Java 17, verifies the runner-provided Android SDK and `sdkmanager`, installs `platform-tools`, Android platform 36, and build-tools 36.0.0 (without requesting obsolete `tools`), runs Gradle tasks and dependency resolution, builds `:app:assembleDebug`, verifies the expected APK is non-empty, and uploads the APK plus diagnostics. It does not assume the APK exists merely because Gradle was invoked. The separate in-app builder template listens for a published Release tagged `apkbuild-*` and builds user-uploaded source ZIPs.

If the project needs a specific task (for example a non-default application module task), set the repository Actions variable **`APK_BUILD_TASK`** to a task name matching `[A-Za-z0-9:_-]+`, such as `:mobile:assembleDebug`. Verify the actual task exists in that project. A release APK is not signed automatically and no release signing secret should be placed in a source ZIP.

Action references in the workflow are pinned to the immutable commit SHA present in the file. Review and update those pins deliberately when refreshing the action versions. Keep workflow token permissions minimal. Uploaded Gradle/build scripts are untrusted code: they run on a temporary hosted runner, and this workflow deliberately does not pass the user's personal token or Gemini key into Gradle. Use a dedicated repository with no unrelated secrets. Consider a separate GitHub organization/repository and stronger runner isolation for sensitive work.

## Local tests and fixtures

- `fixtures/valid-android-project/`: small Android Gradle app fixture (expected to compile once an official wrapper/JDK/SDK and dependencies are available).
- `fixtures/broken-android-project/`: intentionally uncompilable Kotlin fixture.
- `fixtures/*.zip`: valid nested project, malformed ZIP, and ZIP-slip archive fixtures.
- `app/src/test/`: unit tests for project-root detection, packaging exclusions, patch validation/hash checks, GitHub workflow response parsing/state mapping and secret redaction.
- `tools/validate_project.py`: dependency-free repository/workflow/file-structure smoke validation.

Run locally:

```bash
python3 tools/validate_project.py
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

The last two commands require internet, Android SDK 36 and a properly generated official wrapper. Unit tests in the archive have not been executed by Gradle in this generation environment. The local smoke validator is not a substitute for Android compilation or service integration tests.

## Privacy, cleanup and limitations

- Source files are uploaded to a private GitHub Release asset until it is cleaned up. Deleting a Release/tag cannot guarantee immediate deletion from every provider backup/log.
- The app never deletes the original uploaded ZIP merely because AI repair fails. Removing a local project explicitly removes the app-managed workspace and its preserved original ZIP.
- The source packager excludes several obvious signing/credential files but cannot recognize every custom secret format. Review the exclusion preview and never place a production signing key/password in source.
- AI suggestions can be wrong. The validator prevents common path/hash/risk mistakes but does not prove semantic correctness. Every accepted patch must pass a fresh remote build to count as successful.
- Some projects will not build through a generic hosted workflow: projects depending on private Maven credentials, native toolchains, custom SDK components, unsupported Gradle/AGP/Java versions, local machine files, or nonstandard tasks may require manual setup. The app will not silently modify major build versions to make a guess.
- The debug frontend APK and live GitHub/Gemini integration could not be built/tested in the provided environment. See `TEST_REPORT.md` and `BUILD_STATUS.md` for exact status.

## Further documentation

- GitHub REST API: <https://docs.github.com/en/rest>
- Release assets: <https://docs.github.com/en/rest/releases/assets#upload-a-release-asset>
- Actions workflow runs: <https://docs.github.com/en/rest/actions/workflow-runs>
- Fine-grained token permissions: <https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens>
- Gemini models: <https://ai.google.dev/gemini-api/docs/models>
- Gemini pricing: <https://ai.google.dev/gemini-api/docs/pricing>


## Uploading the correct ZIP

Use **AI_APK_Builder_Pro_Source.zip**, which contains the complete Android application source. Do not upload a workflow-only ZIP.

1. Upload `AI_APK_Builder_Pro_Source.zip` to the root of your GitHub repository.
2. Upload `.github/workflows/build-apk.yml` from this project to the same path in the repository.
3. Commit both files.
4. Open Actions → **Build AI APK Builder Pro from Project ZIP** → Run workflow.
5. Download `ai-apk-builder-pro-debug-apk` only after a successful run.

The workflow extracts the ZIP on the GitHub runner, ignores nested fixture projects when detecting the app root, avoids the obsolete SDK package `tools`, and generates missing Gradle Wrapper files using the Gradle version in `gradle-wrapper.properties`.

The Android build and external GitHub/Gemini integrations have not been verified against your credentials or repository. See BUILD_STATUS.md and TEST_REPORT.md.


## SDK license failure recovery

The workflow now accepts licenses against the exact SDK root used by Gradle, then installs Android Platform 36 and Build-Tools 35.0.0 and verifies those directories before invoking Gradle. This addresses runs where the license command accidentally targeted a different SDK root.


## Source repair note

The build package contains APK artifact extraction/checksum verification and bounded patch validation. These implementations are intentionally local and do not imply that a full Android build has passed.


### Latest compile diagnostics

The latest known GitHub run fails during Kotlin compilation. This package includes the known UI model-property compatibility fix and disables optional Room schema export. If the repository's uploaded source still reports `isLowStorageEligible` or `hashIdx`, confirm that the uploaded ZIP matches this package; those identifiers do not exist in the source tree packaged here.


## Audit note

The uploaded v3 source archive was audited. Its confirmed unresolved `ValidatedRepair.isLowRiskAutoEligible` property is now implemented with conservative checks. The bundled workflow asset is synchronized with the root workflow. The Gradle wrapper JAR is absent from the source ZIP; GitHub Actions has a bootstrap step to generate it. A hosted build is still required to verify compilation and artifact upload.
