package com.aipkgbuilder.pro.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aipkgbuilder.pro.BuilderScreen
import com.aipkgbuilder.pro.BuilderUiState
import com.aipkgbuilder.pro.BuilderViewModel
import com.aipkgbuilder.pro.data.BuildAttemptEntity
import com.aipkgbuilder.pro.data.ProjectEntity
import com.aipkgbuilder.pro.gemini.GeminiModel
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuilderApp(viewModel: BuilderViewModel) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var projectToDelete by remember { mutableStateOf<ProjectEntity?>(null) }
    var releaseCleanupConfirm by remember { mutableStateOf(false) }
    var showHelpNotice by remember { mutableStateOf(false) }

    val zipPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) viewModel.selectArchive(uri) }
    val apkSaver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")) { uri -> if (uri != null) viewModel.saveSelectedApk(uri) }
    val logExporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri -> if (uri != null) viewModel.exportLogs(uri) }

    if (state.workflowOverwriteNeeded) {
        AlertDialog(
            onDismissRequest = { viewModel.dismissWorkflowOverwrite() },
            icon = { Icon(Icons.Default.Warning, contentDescription = null) },
            title = { Text("Replace custom workflow?") },
            text = { Text("A different .github/workflows/build-apk.yml exists in the private builder repository. Replacing it may affect its current automation. Compare it with the bundled workflow before confirming.") },
            confirmButton = { Button(onClick = { viewModel.installWorkflow(overwriteDifferent = true) }) { Text("Replace Workflow") } },
            dismissButton = { TextButton(onClick = { viewModel.dismissWorkflowOverwrite() }) { Text("Keep Existing") } }
        )
    }
    projectToDelete?.let { project ->
        AlertDialog(
            onDismissRequest = { projectToDelete = null },
            title = { Text("Delete ${project.name}?") },
            text = { Text("This removes the app-managed workspace, original imported ZIP copy, repair history and local project metadata. It does not delete anything from GitHub. This cannot be undone from the app.") },
            confirmButton = { Button(onClick = { viewModel.deleteProject(project); projectToDelete = null }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("Delete Local Project") } },
            dismissButton = { TextButton(onClick = { projectToDelete = null }) { Text("Cancel") } }
        )
    }
    if (releaseCleanupConfirm) {
        AlertDialog(
            onDismissRequest = { releaseCleanupConfirm = false },
            title = { Text("Delete temporary GitHub Release?") },
            text = { Text("The temporary source Release and tag will be deleted. The local source project and APK will stay. GitHub backups, audit logs or service retention may not disappear immediately.") },
            confirmButton = { Button(onClick = { releaseCleanupConfirm = false; viewModel.deleteTemporaryRelease() }) { Text("Delete Release and Tag") } },
            dismissButton = { TextButton(onClick = { releaseCleanupConfirm = false }) { Text("Cancel") } }
        )
    }
    if (showHelpNotice) {
        AlertDialog(onDismissRequest = { showHelpNotice = false }, title = { Text("About this build") },
            text = { Text("The workflow builds untrusted uploaded Gradle projects on a temporary GitHub-hosted runner. Never provide signing keys or production secrets. A debug APK that builds successfully is not necessarily ready for Play Store release.") },
            confirmButton = { TextButton(onClick = { showHelpNotice = false }) { Text("Got it") } })
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Icon(Icons.Default.Android, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("AI APK Builder Pro", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Upload · Analyze · Build · Fix", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                HorizontalDivider()
                LazyColumn(Modifier.weight(1f)) {
                    items(BuilderScreen.entries.toList()) { screen ->
                        NavigationDrawerItem(
                            label = { Text(screen.title) },
                            selected = state.screen == screen,
                            onClick = { viewModel.navigate(screen); scope.launch { drawerState.close() } },
                            icon = { Icon(iconFor(screen), contentDescription = null) },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                        )
                    }
                }
                Text("Personal testing edition · v1.0.0", Modifier.padding(16.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("AI APK Builder Pro", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(state.screen.title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    },
                    navigationIcon = { IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, contentDescription = "Open navigation") } },
                    actions = {
                        if (state.busy) CircularProgressIndicator(Modifier.padding(end = 14.dp).size(24.dp), strokeWidth = 2.dp)
                        else IconButton(onClick = { viewModel.refreshBuildStatus(silent = false) }) { Icon(Icons.Default.Refresh, contentDescription = "Refresh build status") }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf(BuilderScreen.HOME, BuilderScreen.NEW_PROJECT, BuilderScreen.PROJECTS, BuilderScreen.GITHUB).forEach { screen ->
                        NavigationBarItem(selected = state.screen == screen, onClick = { viewModel.navigate(screen) }, icon = { Icon(iconFor(screen), contentDescription = null) }, label = { Text(screen.title.removeSuffix(" Settings")) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (state.busy) {
                    LinearProgressIndicator(progress = { state.progress.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Text(state.progressLabel, Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                MessageBanner(state)
                when (state.screen) {
                    BuilderScreen.HOME -> HomeScreen(state, viewModel, onSelectZip = { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, onHelp = { showHelpNotice = true })
                    BuilderScreen.NEW_PROJECT -> NewProjectScreen(state, viewModel, onSelectZip = { zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) })
                    BuilderScreen.PROJECTS -> ProjectsScreen(state, viewModel, onDelete = { projectToDelete = it })
                    BuilderScreen.HISTORY -> HistoryScreen(state, viewModel)
                    BuilderScreen.GITHUB -> GitHubSettingsScreen(state, viewModel)
                    BuilderScreen.GEMINI -> GeminiSettingsScreen(state, viewModel)
                    BuilderScreen.AI_FIXER -> AIFixerScreen(state, viewModel)
                    BuilderScreen.LOGS -> LogsScreen(state, viewModel, onExport = { fileName -> logExporter.launch(fileName) })
                    BuilderScreen.DOWNLOADS -> DownloadsScreen(state, viewModel, onSaveApk = { name -> apkSaver.launch(name) })
                    BuilderScreen.PRIVACY -> PrivacyScreen(state, viewModel, onDeleteRelease = { releaseCleanupConfirm = true })
                    BuilderScreen.HELP -> HelpScreen(viewModel)
                }
            }
        }
    }
}

@Composable
private fun MessageBanner(state: BuilderUiState) {
    if (state.message.isBlank()) return
    val bg = if (state.isError) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (state.isError) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant
    Surface(color = bg, contentColor = fg, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 9.dp), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(if (state.isError) Icons.Default.ErrorOutline else Icons.Default.Info, contentDescription = null, modifier = Modifier.size(18.dp))
            Text(state.message, style = MaterialTheme.typography.bodySmall, maxLines = 6, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun HomeScreen(state: BuilderUiState, vm: BuilderViewModel, onSelectZip: () -> Unit, onHelp: () -> Unit) {
    ScreenColumn {
        Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Your Android project, built in the cloud", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Select a ZIP from your phone. GitHub Actions performs the actual Gradle build; Gemini can help diagnose eligible failures.", style = MaterialTheme.typography.bodyMedium)
                Button(onClick = onSelectZip, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) {
                    Icon(Icons.Default.UploadFile, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Upload Project ZIP")
                }
                OutlinedButton(onClick = { vm.navigate(BuilderScreen.GITHUB) }, modifier = Modifier.fillMaxWidth()) { Text("Configure GitHub Builder") }
            }
        }
        SectionTitle("Live overview")
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            StatCard("Projects", state.projects.size.toString(), "Saved locally", Modifier.weight(1f), Icons.Default.FolderOpen)
            StatCard("Build attempts", state.buildAttempts.size.toString(), "From local history", Modifier.weight(1f), Icons.Default.History)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            StatCard("Successful", state.buildAttempts.count { it.status == "SUCCEEDED" }.toString(), "Verified APK artifact", Modifier.weight(1f), Icons.Default.CheckCircle)
            StatCard("Failed", state.buildAttempts.count { it.status == "FAILED" }.toString(), "Review diagnostics", Modifier.weight(1f), Icons.Default.ErrorOutline)
        }
        SectionTitle("Connection status")
        StatusRow("GitHub builder", state.githubStatus, if (state.githubStatus.startsWith("Verified")) Icons.Default.CheckCircle else Icons.Default.CloudOff)
        StatusRow("Gemini AI", state.geminiStatus, if (state.geminiStatus.startsWith("Verified")) Icons.Default.CheckCircle else Icons.Default.Psychology)
        state.activeProject?.let { project ->
            SectionTitle("Current project")
            CardRow {
                Text(project.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Status: ${project.currentStatus}", style = MaterialTheme.typography.bodyMedium)
                Text(project.lastMessage ?: "No build has been run yet.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.prepareBuild(project) }, enabled = !state.busy) { Text("Prepare Build") }
                    OutlinedButton(onClick = { vm.navigate(BuilderScreen.PROJECTS) }) { Text("Project Details") }
                }
            }
        }
        SectionTitle("Setup checklist")
        ChecklistRow("Dedicated private GitHub repository", state.githubStatus.startsWith("Verified"))
        ChecklistRow("Build workflow installed", state.workflowInstalled == true)
        ChecklistRow("Gemini API tested (optional)", state.geminiStatus.startsWith("Verified"))
        Text("A checked item reflects a real configuration or API result stored by this app, not a simulated dashboard counter.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedButton(onClick = onHelp, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Warning, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Important safety notes") }
    }
}

@Composable
private fun NewProjectScreen(state: BuilderUiState, vm: BuilderViewModel, onSelectZip: () -> Unit) {
    ScreenColumn {
        SectionTitle("Project ZIP from your phone")
        Text("Use the Android document picker. No broad storage permission is required. The source archive is copied into app-private storage and is not executed on this device.", style = MaterialTheme.typography.bodyMedium)
        Button(onClick = onSelectZip, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) { Icon(Icons.Default.FolderOpen, contentDescription = null); Spacer(Modifier.width(8.dp)); Text(if (state.selectedArchive == null) "Select Project ZIP" else "Replace ZIP") }
        state.selectedArchive?.let { archive ->
            CardRow {
                Text(archive.displayName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("File size: ${humanSize(archive.sizeBytes)}", style = MaterialTheme.typography.bodyMedium)
                Text("Path: ${archive.file.absolutePath}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.analyzeSelectedArchive() }, enabled = !state.busy) { Text("Extract & Analyze") }
                    OutlinedButton(onClick = { vm.clearSelectedArchive() }, enabled = !state.busy) { Text("Clear Selection") }
                }
            }
        }
        state.summary?.let { summary ->
            SectionTitle("Analysis report")
            CardRow {
                StatusRow("Readiness", summary.readiness, if (summary.readiness == "Ready to attempt build") Icons.Default.CheckCircle else Icons.Default.Warning)
                SummaryValue("Project root", summary.projectRoot.absolutePath)
                SummaryValue("Modules", summary.modules.joinToString { "${it.name}${if (it.applicationModule) " (application)" else ""}" }.ifBlank { "Not detected" })
                SummaryValue("Application ID", summary.applicationId ?: "Not detected")
                SummaryValue("SDK versions", "min ${summary.minSdk ?: "?"} · target ${summary.targetSdk ?: "?"} · compile ${summary.compileSdk ?: "?"}")
                SummaryValue("Build tools", "Kotlin ${summary.kotlinVersion ?: "?"} · AGP ${summary.agpVersion ?: "?"} · Gradle ${summary.gradleVersion ?: "?"} · Java ${summary.javaCompatibility ?: "?"}")
                SummaryValue("Files", "${summary.totalFileCount} total · ${summary.sourceFileCount} source/config files")
                if (summary.warnings.isNotEmpty()) {
                    HorizontalDivider()
                    summary.warnings.forEach { WarningRow(it) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.prepareBuild() }, enabled = !state.busy) { Icon(Icons.Default.Build, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Prepare Build ZIP") }
                    OutlinedButton(onClick = { vm.navigate(BuilderScreen.GITHUB) }) { Text("GitHub Setup") }
                }
            }
        }
        state.packagingReport?.let { report ->
            SectionTitle("Source upload preview")
            CardRow {
                Text("${report.includedFiles} files included", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("${humanSize(report.sourceZip.length())} · SHA-256 ${report.sha256}", style = MaterialTheme.typography.bodySmall)
                if (report.excludedPaths.isEmpty()) Text("No paths were excluded by the current rules.") else {
                    Text("${report.excludedPaths.size} excluded path(s) — review before upload", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                    report.excludedPaths.take(100).forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    if (report.excludedPaths.size > 100) Text("… plus ${report.excludedPaths.size - 100} more", style = MaterialTheme.typography.bodySmall)
                }
                Text("Excluded items remain inside the locally preserved original archive/extracted project. The release asset is uploaded only to a verified private repository.", style = MaterialTheme.typography.bodySmall)
                Button(onClick = { vm.confirmUploadAndBuild() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) { Icon(Icons.Default.CloudUpload, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Confirm & Upload Build") }
                OutlinedButton(onClick = { vm.clearSelectedArchive() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) { Text("Cancel Package") }
            }
        }
    }
}

@Composable
private fun ProjectsScreen(state: BuilderUiState, vm: BuilderViewModel, onDelete: (ProjectEntity) -> Unit) {
    var renameTarget by remember { mutableStateOf<ProjectEntity?>(null) }
    var renameValue by remember { mutableStateOf("") }
    renameTarget?.let { project ->
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename project") },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it },
                    label = { Text("Project name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    vm.renameProject(project, renameValue)
                    renameTarget = null
                }, enabled = renameValue.trim().isNotEmpty()) { Text("Save name") }
            },
            dismissButton = { TextButton(onClick = { renameTarget = null }) { Text("Cancel") } }
        )
    }
    ScreenColumn {
        SectionTitle("Saved projects")
        Text("${state.projects.size} project(s) in this device's local database.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (state.projects.isEmpty()) EmptyState("No projects yet", "Upload an Android Studio ZIP to create your first project.", Icons.Default.FolderOpen)
        state.projects.forEach { project ->
            CardRow {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Android, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(project.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(project.originalArchiveName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    StatusPill(project.currentStatus)
                }
                Text("Created ${formatDate(project.createdAt)}", style = MaterialTheme.typography.labelSmall)
                Text(project.lastMessage ?: "Not built yet", style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { vm.openProject(project) }, enabled = !state.busy, modifier = Modifier.weight(1f)) { Text("Open Project") }
                    OutlinedButton(onClick = { vm.prepareBuild(project) }, enabled = !state.busy, modifier = Modifier.weight(1f)) { Text("Rebuild") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { renameTarget = project; renameValue = project.name }, modifier = Modifier.weight(1f)) { Text("Rename") }
                    TextButton(onClick = { onDelete(project) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Delete") }
                }
            }
        }
    }
}

@Composable
private fun HistoryScreen(state: BuilderUiState, vm: BuilderViewModel) {
    ScreenColumn {
        SectionTitle("Build attempts")
        Text("Each entry is backed by a local record written during a real GitHub Release/Actions operation.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (state.buildAttempts.isEmpty()) EmptyState("No build history", "A build attempt is added when an upload is about to start.", Icons.Default.History)
        state.buildAttempts.forEach { attempt ->
            CardRow {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Attempt ${attempt.attemptNumber}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    StatusPill(attempt.status)
                }
                Text(attempt.releaseTag, style = MaterialTheme.typography.bodySmall)
                Text("Started ${formatDate(attempt.startedAt)}", style = MaterialTheme.typography.labelSmall)
                attempt.message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.openBuildAttempt(attempt) }, modifier = Modifier.weight(1f), enabled = attempt.workflowRunId != null) { Text("Open GitHub Run") }
                    OutlinedButton(onClick = { vm.navigate(BuilderScreen.LOGS) }, modifier = Modifier.weight(1f)) { Text("View Logs") }
                }
            }
        }
        Button(onClick = { vm.refreshBuildStatus() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && state.activeProject?.releaseTag != null) { Icon(Icons.Default.Refresh, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Refresh Active Build") }
        OutlinedButton(onClick = { vm.stopMonitoring() }, modifier = Modifier.fillMaxWidth(), enabled = state.monitoringTag != null) { Text("Cancel Monitoring (remote job continues)") }
        OutlinedButton(onClick = { vm.cancelRemoteBuild() }, modifier = Modifier.fillMaxWidth(), enabled = state.activeProject?.workflowRunId != null) { Text("Cancel Remote GitHub Build") }
    }
}

@Composable
private fun GitHubSettingsScreen(state: BuilderUiState, vm: BuilderViewModel) {
    var owner by rememberSaveable { mutableStateOf(vm.savedGitHubOwner()) }
    var repository by rememberSaveable { mutableStateOf(vm.savedGitHubRepository()) }
    var branch by rememberSaveable { mutableStateOf(vm.savedGitHubBranch()) }
    var token by remember { mutableStateOf("") }
    var showToken by remember { mutableStateOf(false) }
    ScreenColumn {
        SectionTitle("Private GitHub builder")
        Text("Use a dedicated private repository containing only this builder workflow and temporary Release assets. The app never pushes your source tree as a Git commit; it uploads a source ZIP to a unique draft Release.", style = MaterialTheme.typography.bodyMedium)
        CardRow {
            OutlinedTextField(owner, { owner = it }, label = { Text("Repository owner / username") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(repository, { repository = it }, label = { Text("Private builder repository") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(branch, { branch = it }, label = { Text("Default branch") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(token, { token = it }, label = { Text(if (vm.hasSavedGitHubToken()) "Personal Access Token (saved token remains active until test succeeds)" else "Fine-grained Personal Access Token") }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                visualTransformation = if (showToken) VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { IconButton(onClick = { showToken = !showToken }) { Icon(if (showToken) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = "Toggle token visibility") } })
            Text("Minimum permissions normally include Metadata read, Contents write, Workflows write for workflow installation, and Actions read for run/artifact/log tracking. Exact endpoint requirements can vary; the live API error is shown if permission is missing.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = { vm.testGitHubConnection(token, owner, repository, branch) }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && token.isNotBlank() && owner.isNotBlank() && repository.isNotBlank()) { Icon(Icons.Default.Link, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Test Connection & Save") }
            Text("Status: ${state.githubStatus}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            OutlinedButton(onClick = { vm.retestSavedGitHubConnection() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && vm.hasSavedGitHubToken()) { Text("Re-test Saved Connection") }
            OutlinedButton(onClick = { vm.verifyGitHubRepositoryPermissions() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && vm.hasSavedGitHubToken()) { Text("Verify Repository Permissions") }
            OutlinedButton(onClick = { vm.verifyGitHubActions() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && vm.hasSavedGitHubToken()) { Text("Verify GitHub Actions Availability") }
            OutlinedButton(onClick = { vm.installWorkflow() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && vm.hasSavedGitHubToken()) { Icon(Icons.Default.Code, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Install / Verify Build Workflow") }
            if (state.workflowOverwriteNeeded) OutlinedButton(onClick = { vm.installWorkflow(overwriteDifferent = true) }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) { Text("Replace Workflow (I reviewed the risk)") }
            OutlinedButton(onClick = { vm.openUrl("https://github.com/${owner.trim()}/${repository.trim()}") }, modifier = Modifier.fillMaxWidth(), enabled = owner.isNotBlank() && repository.isNotBlank()) { Icon(Icons.Default.OpenInNew, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Open Repository") }
            OutlinedButton(onClick = { vm.openUrl("https://github.com/${owner.trim()}/${repository.trim()}/settings/actions") }, modifier = Modifier.fillMaxWidth(), enabled = owner.isNotBlank() && repository.isNotBlank()) { Text("Open GitHub Actions Settings") }
            TextButton(onClick = { vm.removeGitHubCredentials(); token = "" }, modifier = Modifier.fillMaxWidth()) { Text("Remove Saved GitHub Token", color = MaterialTheme.colorScheme.error) }
        }
        SectionTitle("Repository privacy & source handling")
        WarningRow("The app blocks build uploads when repository privacy cannot be verified as private. GitHub Release source ZIPs remain there until cleanup.")
        WarningRow("A user-uploaded Gradle project can execute arbitrary build scripts on the GitHub runner. The workflow uses a separate hosted runner, a read-only GITHUB_TOKEN during source download, and does not pass the personal access token into Gradle.")
        OutlinedButton(onClick = { vm.openUrl("https://docs.github.com/en/rest/releases/assets#upload-a-release-asset") }, modifier = Modifier.fillMaxWidth()) { Text("GitHub: Release Asset API") }
        OutlinedButton(onClick = { vm.openUrl("https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens") }, modifier = Modifier.fillMaxWidth()) { Text("GitHub: Token Permission Reference") }
    }
}

@Composable
private fun GeminiSettingsScreen(state: BuilderUiState, vm: BuilderViewModel) {
    var apiKey by remember { mutableStateOf("") }
    var model by rememberSaveable { mutableStateOf(vm.savedGeminiModel()) }
    var showKey by remember { mutableStateOf(false) }
    ScreenColumn {
        SectionTitle("Gemini API")
        Text("AI is optional. Builds without Gemini remain available. Test & Save validates the current key and model with an actual generateContent request.", style = MaterialTheme.typography.bodyMedium)
        CardRow {
            OutlinedTextField(apiKey, { apiKey = it }, modifier = Modifier.fillMaxWidth(), label = { Text(if (vm.hasSavedGeminiKey()) "New Gemini API key (saved key stays active until test succeeds)" else "Gemini API key") }, singleLine = true,
                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(), trailingIcon = { IconButton(onClick = { showKey = !showKey }) { Icon(if (showKey) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = "Toggle API key visibility") } })
            OutlinedTextField(model, { model = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Model ID") }, singleLine = true)
            Text("Current saved status: ${state.geminiStatus}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Button(onClick = { vm.testAndSaveGeminiKey(apiKey, model) }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && apiKey.isNotBlank() && model.isNotBlank()) { Icon(Icons.Default.Science, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Test API & Save") }
            OutlinedButton(onClick = { vm.retestSavedGeminiConfiguration() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && vm.hasSavedGeminiKey()) { Text("Test Saved Configuration") }
            OutlinedButton(onClick = { vm.fetchGeminiModels(apiKey) }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && apiKey.isNotBlank()) { Text("Fetch Available Models") }
            if (state.geminiModels.isNotEmpty()) {
                Text("Models that advertise generateContent support", style = MaterialTheme.typography.titleSmall)
                state.geminiModels.take(30).forEach { item -> ModelRow(item, onSelect = { model = item.name }) }
                if (state.geminiModels.size > 30) Text("Showing first 30 of ${state.geminiModels.size} models.", style = MaterialTheme.typography.labelSmall)
            }
            TextButton(onClick = { vm.removeGeminiKey(); apiKey = "" }, modifier = Modifier.fillMaxWidth()) { Text("Remove Saved Gemini Key", color = MaterialTheme.colorScheme.error) }
        }
        SectionTitle("Source consent")
        ConsentCard(state, vm)
        SectionTitle("Official documentation")
        OutlinedButton(onClick = { vm.openUrl("https://ai.google.dev/gemini-api/docs/models") }, modifier = Modifier.fillMaxWidth()) { Text("Supported Models") }
        OutlinedButton(onClick = { vm.openUrl("https://ai.google.dev/gemini-api/docs/pricing") }, modifier = Modifier.fillMaxWidth()) { Text("Pricing & Quotas") }
        OutlinedButton(onClick = { vm.openUrl("https://ai.google.dev/gemini-api/docs/api-key") }, modifier = Modifier.fillMaxWidth()) { Text("API Key Security") }
    }
}

@Composable
private fun ConsentCard(state: BuilderUiState, vm: BuilderViewModel) {
    CardRow {
        Text("Sending source code to Gemini requires explicit consent.", fontWeight = FontWeight.SemiBold)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = state.sourceConsent, onCheckedChange = { vm.setSourceConsent(it) })
            Column(Modifier.weight(1f)) {
                Text("Allow selected source snippets", style = MaterialTheme.typography.bodyMedium)
                Text("Only relevant files/snippets plus actual build logs are sent, with detected secrets redacted. The whole ZIP is never sent by default.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text(if (state.sourceConsent) "Source consent is enabled for this session; confirm again by leaving the checkbox on before using Diagnose." else "Logs-only mode is selected; source files will not be sent.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun AIFixerScreen(state: BuilderUiState, vm: BuilderViewModel) {
    ScreenColumn {
        SectionTitle("AI Error Fixer")
        Text("Diagnosis uses logs from a real completed GitHub Actions run. Infrastructure, credentials, dependency download and quota errors must not be patched as if they were source bugs.", style = MaterialTheme.typography.bodyMedium)
        CardRow {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Auto Fix Mode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                    Text("Automatically applies only validated, very high-confidence Kotlin/Java source updates. All other proposals stop for your review.", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = state.autoFixMode, onCheckedChange = { vm.setAutoFixMode(it) })
            }
            ConsentCard(state, vm)
            Button(onClick = { vm.diagnoseCurrentFailure() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && state.logs.isNotBlank() && state.logs != "No logs loaded yet.") { Icon(Icons.Default.Psychology, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Diagnose with Gemini") }
            OutlinedButton(onClick = { vm.stopAIRepair() }, modifier = Modifier.fillMaxWidth(), enabled = state.busy) { Text("Stop AI Request") }
        }
        state.repairDiagnosis?.let { diagnosis ->
            SectionTitle("Diagnosis")
            CardRow {
                StatusRow("Category", diagnosis.errorCategory, Icons.Default.BugReport)
                SummaryValue("Confidence", "${(diagnosis.confidence * 100).toInt()}% (model estimate, not a guarantee)")
                SummaryValue("Likely root cause", diagnosis.rootCause)
                Text(diagnosis.explanation, style = MaterialTheme.typography.bodyMedium)
                if (diagnosis.validationPlan.isNotEmpty()) {
                    Text("Validation plan", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    diagnosis.validationPlan.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        state.repairValidationError?.let { WarningRow("Patch validation stopped the repair: $it") }
        state.repairProposal?.let { proposal ->
            SectionTitle("Proposed patch review")
            CardRow {
                Text("${proposal.changes.size} file change(s)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(if (proposal.isLowRiskAutoEligible) "Eligible for low-risk Auto Fix" else "Requires manual review/approval", style = MaterialTheme.typography.bodySmall, color = if (proposal.isLowRiskAutoEligible) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                proposal.changes.forEach { change ->
                    HorizontalDivider()
                    Text("${change.operation}: ${change.path}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Text(change.justification, style = MaterialTheme.typography.bodySmall)
                    Text("Expected original SHA-256: ${change.originalSha256}", style = MaterialTheme.typography.labelSmall)
                }
                if (state.repairPreview.isNotBlank()) {
                    Text("Before / after preview", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
                        Text(state.repairPreview, Modifier.fillMaxWidth().padding(12.dp), style = MaterialTheme.typography.bodySmall)
                    }
                }
                Button(onClick = { vm.applyApprovedRepair() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && proposal.changes.isNotEmpty()) { Icon(Icons.Default.Check, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Approve & Apply Patch") }
            }
        }
        if (state.repairFilesApplied.isNotEmpty()) {
            SectionTitle("Last applied repair")
            state.repairFilesApplied.forEach { Text("✓ $it", color = MaterialTheme.colorScheme.primary) }
            OutlinedButton(onClick = { vm.navigate(BuilderScreen.NEW_PROJECT) }, modifier = Modifier.fillMaxWidth()) { Text("Review Prepared Rebuild") }
        }
    }
}

@Composable
private fun LogsScreen(state: BuilderUiState, vm: BuilderViewModel, onExport: (String) -> Unit) {
    var search by rememberSaveable { mutableStateOf("") }
    val visible = remember(state.logs, search) {
        val source = state.logs.lines()
        if (search.isBlank()) source else source.filter { it.contains(search, ignoreCase = true) }
    }
    ScreenColumn {
        SectionTitle("Logs & diagnostics")
        state.activeProject?.let { project ->
            SummaryValue("Project", project.name)
            SummaryValue("Remote status", project.currentStatus)
            SummaryValue("Release tag", project.releaseTag ?: "Not available")
            SummaryValue("Workflow run ID", project.workflowRunId?.toString() ?: "Not available")
        }
        OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Search logs") }, leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.copyText(visible.joinToString("\n")) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.ContentCopy, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("Copy Logs") }
            OutlinedButton(onClick = { onExport("apk-builder-diagnostics.txt") }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Save, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("Export Report") }
        }
        OutlinedButton(onClick = { vm.openCurrentWorkflow() }, modifier = Modifier.fillMaxWidth(), enabled = state.workflowUrl != null || state.activeProject?.workflowRunId != null) { Icon(Icons.Default.OpenInNew, contentDescription = null); Spacer(Modifier.width(6.dp)); Text("Open GitHub Run") }
        OutlinedButton(onClick = { vm.diagnoseCurrentFailure() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && state.logs != "No logs loaded yet.") { Text("AI Diagnosis") }
        Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(12.dp)) {
            Text(visible.joinToString("\n"), Modifier.fillMaxWidth().padding(12.dp), style = MaterialTheme.typography.bodySmall)
        }
        Text("Logs shown here are sanitized where detected. Incomplete or unavailable logs are called out instead of being represented as a successful build.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun DownloadsScreen(state: BuilderUiState, vm: BuilderViewModel, onSaveApk: (String) -> Unit) {
    ScreenColumn {
        SectionTitle("Generated APKs")
        if (state.apks.isEmpty()) EmptyState("No APK artifact available", "A successful workflow run must upload a verified APK artifact before this screen can save it.", Icons.Default.Download)
        state.apks.forEachIndexed { index, apk ->
            CardRow {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = state.selectedApkIndex == index, onClick = { vm.selectApk(index) })
                    Column(Modifier.weight(1f)) {
                        Text(apk.file.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text(apk.relativePath, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                SummaryValue("Size", humanSize(apk.sizeBytes))
                SummaryValue("SHA-256", apk.sha256)
                SummaryValue("APK validation", "AndroidManifest.xml present · DEX ${if (apk.hasDex) "present" else "not detected"}")
                StatusPill("DEBUG / UNCLASSIFIED")
            }
        }
        Button(onClick = { state.apks.getOrNull(state.selectedApkIndex)?.let { onSaveApk(it.file.name) } }, modifier = Modifier.fillMaxWidth(), enabled = state.apks.isNotEmpty() && !state.busy) { Icon(Icons.Default.Download, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Save Selected APK to Phone") }
        OutlinedButton(onClick = { vm.refreshBuildStatus() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && state.activeProject?.releaseTag != null) { Text("Refresh Artifact Status") }
        Text("APK files are saved through Android's document picker and re-read to verify exact size and SHA-256. Signing/package/version data not read by this implementation is not invented.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PrivacyScreen(state: BuilderUiState, vm: BuilderViewModel, onDeleteRelease: () -> Unit) {
    ScreenColumn {
        SectionTitle("Privacy, storage and cleanup")
        CardRow {
            SummaryValue("App-managed storage", humanSize(state.storageBytes))
            SummaryValue("Saved projects", state.projects.size.toString())
            SummaryValue("Downloaded APKs in current session", state.apks.size.toString())
            Text("Credentials are encrypted with an Android Keystore-backed AES-GCM key. This protects local storage at rest but is not a server-side vault; credentials could be extracted from a compromised device.", style = MaterialTheme.typography.bodyMedium)
            Text("The source ZIP is uploaded to a private GitHub Release asset. Release deletion does not guarantee immediate permanent erasure from service backups or audit records.", style = MaterialTheme.typography.bodyMedium)
        }
        SectionTitle("Cleanup actions")
        OutlinedButton(onClick = { vm.cleanTemporaryFiles() }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) { Icon(Icons.Default.DeleteSweep, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Clean Temporary Files") }
        OutlinedButton(onClick = onDeleteRelease, modifier = Modifier.fillMaxWidth(), enabled = !state.busy && state.activeProject?.releaseId != null) { Text("Delete Temporary GitHub Release & Tag") }
        OutlinedButton(onClick = { vm.removeGitHubCredentials() }, modifier = Modifier.fillMaxWidth()) { Text("Remove GitHub Credentials") }
        OutlinedButton(onClick = { vm.removeGeminiKey() }, modifier = Modifier.fillMaxWidth()) { Text("Remove Gemini API Key") }
        WarningRow("The original ZIP is preserved unless you delete the local project workspace. Do not upload signing keys, production API keys, private keystores, or other secrets in your project.")
        WarningRow("Source snippets are not sent to Gemini unless the source-consent checkbox is enabled. Logs are still redacted where recognizable, but automated redaction cannot guarantee every secret format will be detected.")
    }
}

@Composable
private fun HelpScreen(vm: BuilderViewModel) {
    ScreenColumn {
        SectionTitle("Setup and troubleshooting")
        CardRow {
            Text("त्वरित हिंदी मार्गदर्शन", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("पहले GitHub पर एक अलग Private repository बनाएँ और ऐप में token से connection जाँचें। Workflow install करें और GitHub Actions चालू रखें। फिर फोन से Android Studio project की ZIP चुनें, Extract & Analyze दबाएँ, excluded files की सूची जाँचें और build upload की पुष्टि करें। Build status GitHub Actions से आएगा। Gemini वैकल्पिक है; source code भेजने से पहले consent दें। सफल debug APK को Downloads में खोलकर Android की Save dialog से सेव करें।")
            Text("सावधानी: ZIP में signing keys, passwords या production secrets न रखें। APK build सफल होना Play Store readiness का प्रमाण नहीं है।")
        }
        HelpItem("1. Create a dedicated private GitHub repository", "Do not use a public project repository or a repository containing production secrets.")
        HelpItem("2. Create a fine-grained token", "Limit repository access to the builder repo. Enable Metadata read, Contents write and Workflows write to install a workflow, plus Actions read to track runs/artifacts/logs.")
        HelpItem("3. Test GitHub and install workflow", "Use GitHub Settings. Confirm GitHub Actions is enabled. Keep the bundled release trigger limited to apkbuild-* tags.")
        HelpItem("4. Select an Android Studio project ZIP", "No manual unzipping is needed. The app checks path traversal, suspicious entries, expanded size and duplicate paths.")
        HelpItem("5. Prepare and review the source ZIP", "Build output, local.properties, .git and detected signing/secret files are excluded. Review the list before upload.")
        HelpItem("6. Build and diagnose", "GitHub Actions status is taken from the matching real workflow run. Gemini repair is optional and every patch is hash-checked before application.")
        HelpItem("7. Debug APK limitations", "A successful assembleDebug result does not validate application behavior, release signing, Play Store requirements, or every runtime feature.")
        OutlinedButton(onClick = { vm.openUrl("https://docs.github.com/en/actions") }, modifier = Modifier.fillMaxWidth()) { Text("GitHub Actions Documentation") }
        OutlinedButton(onClick = { vm.openUrl("https://ai.google.dev/gemini-api/docs") }, modifier = Modifier.fillMaxWidth()) { Text("Gemini API Documentation") }
        OutlinedButton(onClick = { vm.openUrl("https://developer.android.com/studio") }, modifier = Modifier.fillMaxWidth()) { Text("Android Studio") }
    }
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable
private fun CardRow(content: @Composable ColumnScope.() -> Unit) {
    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
}

@Composable
private fun StatCard(title: String, value: String, helper: String, modifier: Modifier = Modifier, icon: ImageVector) {
    ElevatedCard(modifier = modifier, shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(helper, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StatusRow(title: String, detail: String, icon: ImageVector) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 2.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
            Text(detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SummaryValue(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun WarningRow(text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Top) {
        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
        Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
    }
}

@Composable
private fun ChecklistRow(label: String, complete: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(if (complete) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, contentDescription = null, tint = if (complete) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun StatusPill(status: String) {
    val success = status.equals("SUCCEEDED", true) || status.equals("VERIFIED", true)
    val bad = status.equals("FAILED", true) || status.contains("ERROR", true)
    val background = when { success -> MaterialTheme.colorScheme.primaryContainer; bad -> MaterialTheme.colorScheme.errorContainer; else -> MaterialTheme.colorScheme.surfaceVariant }
    val foreground = when { success -> MaterialTheme.colorScheme.onPrimaryContainer; bad -> MaterialTheme.colorScheme.onErrorContainer; else -> MaterialTheme.colorScheme.onSurfaceVariant }
    Surface(color = background, contentColor = foreground, shape = RoundedCornerShape(50), border = BorderStroke(0.5.dp, foreground.copy(alpha = 0.25f))) {
        Text(status.replace('_', ' '), Modifier.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}

@Composable
private fun EmptyState(title: String, message: String, icon: ImageVector) {
    CardRow {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(38.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ModelRow(model: GeminiModel, onSelect: () -> Unit) {
    OutlinedCard(onClick = onSelect, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp)) {
            Text(model.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            if (model.displayName.isNotBlank()) Text(model.displayName, style = MaterialTheme.typography.labelSmall)
            if (model.description.isNotBlank()) Text(model.description.take(180), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HelpItem(title: String, description: String) {
    CardRow {
        Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Text(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun iconFor(screen: BuilderScreen): ImageVector = when (screen) {
    BuilderScreen.HOME -> Icons.Default.Home
    BuilderScreen.NEW_PROJECT -> Icons.Default.UploadFile
    BuilderScreen.PROJECTS -> Icons.Default.FolderOpen
    BuilderScreen.HISTORY -> Icons.Default.History
    BuilderScreen.AI_FIXER -> Icons.Default.Psychology
    BuilderScreen.GITHUB -> Icons.Default.Code
    BuilderScreen.GEMINI -> Icons.Default.Key
    BuilderScreen.LOGS -> Icons.Default.Terminal
    BuilderScreen.DOWNLOADS -> Icons.Default.Download
    BuilderScreen.PRIVACY -> Icons.Default.Security
    BuilderScreen.HELP -> Icons.Default.HelpOutline
}

private fun formatDate(epochMillis: Long): String = runCatching {
    DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm").withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(epochMillis))
}.getOrDefault("Unknown time")

private fun humanSize(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024L * 1024 -> "%.1f KB".format(bytes / 1024.0)
    bytes < 1024L * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
    else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
}
