package com.aipkgbuilder.pro

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.aipkgbuilder.pro.build.ArtifactProcessor
import com.aipkgbuilder.pro.build.ApkArtifact
import com.aipkgbuilder.pro.build.PatchValidationException
import com.aipkgbuilder.pro.build.PatchValidator
import com.aipkgbuilder.pro.build.ValidatedRepair
import com.aipkgbuilder.pro.data.BuildAttemptEntity
import com.aipkgbuilder.pro.data.BuilderDatabase
import com.aipkgbuilder.pro.data.ProjectEntity
import com.aipkgbuilder.pro.github.ArtifactInfo
import com.aipkgbuilder.pro.github.BuildStateMapper
import com.aipkgbuilder.pro.github.GitHubApiException
import com.aipkgbuilder.pro.github.GitHubClient
import com.aipkgbuilder.pro.github.GitHubSettings
import com.aipkgbuilder.pro.github.PublishedBuildRelease
import com.aipkgbuilder.pro.github.WorkflowRunState
import com.aipkgbuilder.pro.gemini.GeminiApiException
import com.aipkgbuilder.pro.gemini.GeminiClient
import com.aipkgbuilder.pro.gemini.GeminiModel
import com.aipkgbuilder.pro.gemini.RepairDiagnosis
import com.aipkgbuilder.pro.security.SecureSecrets
import com.aipkgbuilder.pro.util.Redactor
import com.aipkgbuilder.pro.worker.BuildStatusWorker
import com.aipkgbuilder.pro.zip.PackagingReport
import com.aipkgbuilder.pro.zip.ProjectProcessor
import com.aipkgbuilder.pro.zip.ProjectSummary
import com.aipkgbuilder.pro.zip.SelectedArchive
import com.aipkgbuilder.pro.zip.ZipSafetyException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlin.math.min

@Suppress("EnumEntryName")
enum class BuilderScreen(val title: String) {
    HOME("Home"), NEW_PROJECT("New Project"), PROJECTS("My Projects"), HISTORY("Build History"),
    AI_FIXER("AI Error Fixer"), GITHUB("GitHub Settings"), GEMINI("Gemini Settings"),
    LOGS("Logs & Diagnostics"), DOWNLOADS("Downloads"), PRIVACY("Privacy & Storage"), HELP("Help")
}

data class BuilderUiState(
    val screen: BuilderScreen = BuilderScreen.HOME,
    val projects: List<ProjectEntity> = emptyList(),
    val buildAttempts: List<BuildAttemptEntity> = emptyList(),
    val activeProject: ProjectEntity? = null,
    val selectedArchive: SelectedArchive? = null,
    val summary: ProjectSummary? = null,
    val packagingReport: PackagingReport? = null,
    val busy: Boolean = false,
    val progress: Float = 0f,
    val progressLabel: String = "Ready",
    val message: String = "Choose an Android Studio project ZIP to begin.",
    val isError: Boolean = false,
    val githubStatus: String = "Not configured",
    val geminiStatus: String = "Optional · not configured",
    val workflowUrl: String? = null,
    val workflowInstalled: Boolean? = null,
    val actionsEnabled: Boolean? = null,
    val aiRequestInProgress: Boolean = false,
    val logs: String = "No logs loaded yet.",
    val repairDiagnosis: RepairDiagnosis? = null,
    val repairProposal: ValidatedRepair? = null,
    val repairValidationError: String? = null,
    val repairPreview: String = "",
    val repairFilesApplied: List<String> = emptyList(),
    val autoFixMode: Boolean = false,
    val sourceConsent: Boolean = false,
    val geminiModels: List<GeminiModel> = emptyList(),
    val apks: List<ApkArtifact> = emptyList(),
    val selectedApkIndex: Int = 0,
    val storageBytes: Long = 0L,
    val workflowOverwriteNeeded: Boolean = false,
    val monitoringTag: String? = null
)

class BuilderViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val runtimePrefs = context.getSharedPreferences(RUNTIME_PREFS, Context.MODE_PRIVATE)
    private val secrets = SecureSecrets(context)
    private val dao = BuilderDatabase.get(context).builderDao()
    private val processor = ProjectProcessor(context)
    private val artifactProcessor = ArtifactProcessor()
    private val patchValidator = PatchValidator()
    private val _state = MutableStateFlow(
        BuilderUiState(
            githubStatus = if (secrets.get(GitHubClient.SECRET_GITHUB_TOKEN).isNullOrBlank()) "Not configured" else "Saved · test to verify",
            geminiStatus = if (secrets.get(GeminiClient.SECRET_GEMINI_KEY).isNullOrBlank()) "Optional · not configured" else "Saved · test to verify",
            autoFixMode = prefs.getBoolean(KEY_AUTO_FIX, false),
            sourceConsent = false,
            storageBytes = context.filesDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }
        )
    )
    val state: StateFlow<BuilderUiState> = _state.asStateFlow()
    private val stoppedMonitorTags = mutableSetOf<String>()
    private var aiRequestJob: Job? = null

    init {
        viewModelScope.launch {
            dao.observeProjects().collect { projects ->
                _state.update { current ->
                    val active = current.activeProject?.id?.let { id -> projects.firstOrNull { it.id == id } }
                        ?: projects.firstOrNull { it.id == prefs.getString(KEY_ACTIVE_PROJECT_ID, null) }
                    current.copy(projects = projects, activeProject = active)
                }
            }
        }
        viewModelScope.launch {
            dao.observeBuildAttempts().collect { attempts -> _state.update { it.copy(buildAttempts = attempts) } }
        }
        viewModelScope.launch { restoreActiveProject() }
    }

    fun navigate(screen: BuilderScreen) = _state.update { it.copy(screen = screen, message = it.message, isError = false) }

    fun setSourceConsent(enabled: Boolean) = _state.update { it.copy(sourceConsent = enabled) }

    fun savedGitHubOwner(): String = prefs.getString(BuildStatusWorker.KEY_OWNER, "").orEmpty()
    fun savedGitHubRepository(): String = prefs.getString(BuildStatusWorker.KEY_REPO, "").orEmpty()
    fun savedGitHubBranch(): String = prefs.getString(BuildStatusWorker.KEY_BRANCH, "main").orEmpty()
    fun savedGeminiModel(): String = prefs.getString(KEY_GEMINI_MODEL, DEFAULT_GEMINI_MODEL) ?: DEFAULT_GEMINI_MODEL
    fun hasSavedGitHubToken(): Boolean = !secrets.get(GitHubClient.SECRET_GITHUB_TOKEN).isNullOrBlank()
    fun hasSavedGeminiKey(): Boolean = !secrets.get(GeminiClient.SECRET_GEMINI_KEY).isNullOrBlank()

    fun clearSelectedArchive() {
        val selected = _state.value.selectedArchive
        if (selected != null && selected.file.path.contains("${File.separator}incoming${File.separator}")) selected.file.delete()
        _state.update { it.copy(selectedArchive = null, summary = null, packagingReport = null, message = "Selection cleared. Existing saved projects and their original ZIPs were not deleted.", isError = false) }
    }

    fun openCurrentWorkflow() {
        _state.value.workflowUrl?.let { openUrl(it) } ?: _state.value.activeProject?.workflowRunId?.let { openRunId -> openUrl("https://github.com/${savedGitHubOwner()}/${savedGitHubRepository()}/actions/runs/$openRunId") }
            ?: showError("No GitHub workflow run URL is available yet.")
    }

    fun openBuildAttempt(attempt: BuildAttemptEntity) {
        val runId = attempt.workflowRunId
        if (runId != null) openUrl("https://github.com/${savedGitHubOwner()}/${savedGitHubRepository()}/actions/runs/$runId")
        else _state.update { it.copy(activeProject = it.projects.firstOrNull { p -> p.id == attempt.projectId } ?: it.activeProject, screen = BuilderScreen.HISTORY, message = "This attempt has no recorded workflow run ID yet. Refresh the active project to locate the exact tag.", isError = false) }
    }

    fun setAutoFixMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_AUTO_FIX, enabled).apply()
        _state.update { it.copy(autoFixMode = enabled, message = if (enabled) "Auto Fix enabled: only validated low-risk Kotlin/Java source edits may be applied automatically." else "Safe Repair mode selected; proposed changes require your approval.", isError = false) }
    }

    fun selectArchive(uri: Uri) {
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, progress = 0.01f, progressLabel = "Copying ZIP from Android storage", message = "Reading selected archive…", isError = false, selectedArchive = null, summary = null, packagingReport = null) }
            try {
                val incoming = File(context.filesDir, "incoming").apply { mkdirs() }
                val selected = withContext(Dispatchers.IO) {
                    processor.copySelectedArchive(uri, incoming) { copied, total ->
                        val progress = if (total != null && total > 0) (copied.toDouble() / total).toFloat().coerceIn(0f, 1f) else 0f
                        _state.update { it.copy(progress = progress, progressLabel = "Copying ZIP · ${humanSize(copied)}") }
                    }
                }
                _state.update { it.copy(selectedArchive = selected, progress = 1f, progressLabel = "ZIP copied", message = "Selected ${selected.displayName} (${humanSize(selected.sizeBytes)}). Press Extract & Analyze to continue.", isError = false, screen = BuilderScreen.NEW_PROJECT) }
            } catch (error: Exception) {
                showError("ZIP selection failed: ${error.message ?: error.javaClass.simpleName}")
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    fun analyzeSelectedArchive() {
        val selected = _state.value.selectedArchive ?: run { showError("Select a ZIP file first."); return }
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, progress = 0.03f, progressLabel = "Validating ZIP", message = "Checking archive structure and extraction safety…", isError = false, summary = null, packagingReport = null) }
            try {
                val id = UUID.randomUUID().toString()
                val projectDir = File(context.filesDir, "projects/$id")
                val extractedDir = File(projectDir, "extracted")
                val rootSummary = withContext(Dispatchers.IO) {
                    processor.extractAndAnalyze(selected.file, extractedDir)
                }
                _state.update { it.copy(progress = 0.72f, progressLabel = "Preserving original and creating working copy") }
                val originalCopy = File(projectDir, "original.zip")
                withContext(Dispatchers.IO) {
                    originalCopy.parentFile?.mkdirs()
                    selected.file.inputStream().buffered().use { input -> originalCopy.outputStream().buffered().use { input.copyTo(it) } }
                }
                val working = File(projectDir, "working-project")
                withContext(Dispatchers.IO) { copyDirectory(rootSummary.projectRoot, working) }
                val summary = rootSummary.copy(projectRoot = working)
                val entity = ProjectEntity(
                    id = id,
                    name = summary.detectedName,
                    originalArchiveName = selected.displayName,
                    originalZipPath = originalCopy.absolutePath,
                    workspacePath = projectDir.absolutePath,
                    projectRootPath = working.absolutePath,
                    createdAt = System.currentTimeMillis(),
                    currentStatus = "ANALYZED",
                    lastMessage = summary.readiness
                )
                dao.upsertProject(entity)
                prefs.edit().putString(KEY_ACTIVE_PROJECT_ID, id).apply()
                selected.file.delete()
                _state.update { it.copy(activeProject = entity, summary = summary, selectedArchive = SelectedArchive(originalCopy, selected.displayName, originalCopy.length()), progress = 1f, progressLabel = "Analysis complete", message = "Project analyzed. The uploaded ZIP and extracted original are preserved locally; builds use a separate working copy.", isError = false, screen = BuilderScreen.NEW_PROJECT, apks = emptyList()) }
            } catch (error: Exception) {
                showError("Extract & Analyze failed: ${error.message ?: error.javaClass.simpleName}")
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    fun openProject(project: ProjectEntity) {
        if (_state.value.busy) return
        viewModelScope.launch {
            var shouldRefresh = false
            _state.update { it.copy(busy = true, progressLabel = "Opening project", message = "Loading saved project…", isError = false) }
            try {
                val summary = withContext(Dispatchers.IO) {
                    val root = File(project.projectRootPath)
                    if (!root.isDirectory) throw IOException("Saved working copy is missing. The original ZIP is at ${project.originalZipPath}.")
                    processor.analyzeExistingProjectRoot(root)
                }
                prefs.edit().putString(KEY_ACTIVE_PROJECT_ID, project.id).apply()
                shouldRefresh = project.workflowRunId != null || project.releaseTag != null
                _state.update { it.copy(activeProject = project, summary = summary, selectedArchive = File(project.originalZipPath).takeIf { file -> file.isFile }?.let { SelectedArchive(it, project.originalArchiveName, it.length()) }, screen = BuilderScreen.PROJECTS, message = "Opened ${project.name}.", isError = false) }
            } catch (error: Exception) { showError(error.message ?: "Could not open project.") }
            finally {
                _state.update { it.copy(busy = false) }
                if (shouldRefresh) refreshBuildStatus(silent = true)
            }
        }
    }

    fun renameProject(project: ProjectEntity, newName: String) {
        val clean = newName.trim().take(80)
        if (clean.isBlank()) { showError("Project name cannot be empty."); return }
        viewModelScope.launch {
            dao.upsertProject(project.copy(name = clean))
            _state.update { it.copy(message = "Project renamed to $clean.", isError = false) }
        }
    }

    fun deleteProject(project: ProjectEntity) {
        viewModelScope.launch {
            try {
                dao.deleteAttemptsForProject(project.id)
                dao.deleteProject(project.id)
                withContext(Dispatchers.IO) { File(project.workspacePath).deleteRecursively() }
                if (prefs.getString(KEY_ACTIVE_PROJECT_ID, null) == project.id) prefs.edit().remove(KEY_ACTIVE_PROJECT_ID).apply()
                _state.update { it.copy(activeProject = if (it.activeProject?.id == project.id) null else it.activeProject, summary = if (it.activeProject?.id == project.id) null else it.summary, message = "Local project workspace and history deleted. Original ZIP was inside that workspace.", isError = false) }
            } catch (error: Exception) { showError("Could not delete project: ${error.message}") }
        }
    }

    fun prepareBuild(project: ProjectEntity? = _state.value.activeProject) {
        val entity = project ?: run { showError("Analyze or open a project before building."); return }
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, progress = 0f, progressLabel = "Preparing source ZIP", message = "Packaging the working copy; original project stays untouched…", isError = false, packagingReport = null) }
            try {
                val report = withContext(Dispatchers.IO) {
                    val projectRoot = File(entity.projectRootPath)
                    val outDir = File(entity.workspacePath, "outgoing").apply { mkdirs() }
                    processor.createCleanSourceZip(projectRoot, File(outDir, "source-${System.currentTimeMillis()}.zip"))
                }
                _state.update {
                    it.copy(packagingReport = report, progress = 1f, progressLabel = "Source ZIP ready", message = buildString {
                        append("Prepared ${report.includedFiles} files · ${humanSize(report.sourceZip.length())} · SHA-256 ${report.sha256.take(16)}…")
                        if (report.excludedPaths.isNotEmpty()) append("\nReview ${report.excludedPaths.size} excluded/generated/sensitive path(s) before upload.")
                        else append("\nNo exclusions were detected by filename/content rules.")
                    }, isError = false, screen = BuilderScreen.NEW_PROJECT)
                }
            } catch (error: Exception) { showError("Source packaging failed: ${error.message ?: error.javaClass.simpleName}") }
            finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun confirmUploadAndBuild() {
        val report = _state.value.packagingReport ?: run { showError("Prepare and review a source ZIP first."); return }
        val project = _state.value.activeProject ?: run { showError("No active project."); return }
        if (_state.value.busy) return
        if (secrets.get(GitHubClient.SECRET_GITHUB_TOKEN).isNullOrBlank()) {
            _state.update { it.copy(screen = BuilderScreen.GITHUB, message = "Configure and test a private GitHub builder repository before uploading source.", isError = true) }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(busy = true, progress = 0f, progressLabel = "Connecting to GitHub", message = "Verifying private repository and workflow before upload…", isError = false, workflowUrl = null) }
            try {
                val attempts = dao.getAttemptsForProject(project.id)
                val initialNumber = (attempts.maxOfOrNull { it.attemptNumber } ?: 0) + 1
                performBuildAttempt(project, report, initialNumber, autoRepairDepth = 0)
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (error: Exception) {
                showError("Build start failed: ${error.message ?: error.javaClass.simpleName}")
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    private suspend fun performBuildAttempt(
        project: ProjectEntity,
        report: PackagingReport,
        attemptNumber: Int,
        autoRepairDepth: Int
    ) {
        val settings = currentGitHubSettings()
        val client = GitHubClient(context, settings)
        val connection = client.testConnection()
        if (!connection.isPrivate) throw IOException("Configured repository is not private. Source upload blocked.")
        if (!connection.canPush) throw IOException("GitHub account lacks push access. Add minimum required Contents and Workflows write permissions.")
        if (!client.workflowExists()) throw IOException("Build workflow is not installed. Open GitHub Settings and tap Install / Verify Workflow.")
        val tag = buildTag(project.id, attemptNumber)
        val attemptId = UUID.randomUUID().toString()
        val started = System.currentTimeMillis()
        val attempt = BuildAttemptEntity(
            id = attemptId,
            projectId = project.id,
            attemptNumber = attemptNumber,
            releaseTag = tag,
            status = "UPLOADING",
            startedAt = started,
            message = "Uploading source ZIP to a draft private Release"
        )
        dao.upsertAttempt(attempt)
        dao.upsertProject(project.copy(
            lastBuildAt = started,
            currentStatus = "UPLOADING",
            lastJobId = attemptId,
            releaseTag = tag,
            releaseId = null,
            workflowRunId = null,
            lastMessage = "Uploading source ZIP"
        ))
        _state.update { it.copy(activeProject = project.copy(currentStatus = "UPLOADING", releaseTag = tag, lastJobId = attemptId), monitoringTag = tag, progress = 0.1f, progressLabel = "Uploading source ZIP", message = "Creating a uniquely tagged draft Release and streaming the source ZIP as binary…", isError = false) }
        val release: PublishedBuildRelease = client.publishBuildRelease(report.sourceZip, tag, attemptNumber)
        val releasedProject = (dao.getProject(project.id) ?: project).copy(
            currentStatus = "QUEUED",
            releaseTag = release.tag,
            releaseId = release.releaseId,
            lastMessage = "Release published; waiting for the matching GitHub Actions workflow run"
        )
        dao.upsertProject(releasedProject)
        dao.upsertAttempt(attempt.copy(releaseId = release.releaseId, status = "QUEUED", message = "Release published; waiting for exact tag match"))
        addPendingTag(tag)
        scheduleBuildTracking()
        _state.update { it.copy(activeProject = releasedProject, workflowUrl = null, progress = 0.2f, progressLabel = "Release published · waiting for workflow", message = "Source asset ${humanSize(release.assetSize)} uploaded and verified. Release published. Monitoring only workflow runs associated with tag $tag.", isError = false) }
        val result = monitorWorkflow(client, releasedProject, attempt.copy(releaseId = release.releaseId, status = "QUEUED"), report, autoRepairDepth)
        if (!result.success && _state.value.autoFixMode && autoRepairDepth < MAX_REPAIR_ATTEMPTS && _state.value.sourceConsent) {
            val repaired = tryAutomaticRepair(project.id, tag, result.logs, attemptNumber, autoRepairDepth)
            if (repaired) return
        }
    }

    private data class AttemptResult(val success: Boolean, val logs: String, val run: WorkflowRunState?)

    private suspend fun monitorWorkflow(
        client: GitHubClient,
        project: ProjectEntity,
        attempt: BuildAttemptEntity,
        report: PackagingReport,
        autoRepairDepth: Int
    ): AttemptResult {
        var delayMs = 2500L
        var run: WorkflowRunState? = null
        var polls = 0
        while (polls < 160) {
            if (attempt.releaseTag in stoppedMonitorTags) {
                _state.update { it.copy(message = "Monitoring stopped locally. GitHub Actions may still be running; refresh this job to resume.", isError = false, progressLabel = "Monitoring paused") }
                return AttemptResult(false, _state.value.logs, run)
            }
            val currentRun = client.findWorkflowRun(attempt.releaseTag)
            run = currentRun
            polls++
            if (currentRun != null) {
                val status = BuildStateMapper.fromRemote(currentRun.status, currentRun.conclusion)
                val storedProject = (dao.getProject(project.id) ?: project).copy(
                    workflowRunId = currentRun.runId,
                    currentStatus = status,
                    lastMessage = currentRun.currentStep ?: currentRun.conclusion ?: currentRun.status
                )
                val storedAttempt = (dao.getAttemptByTag(attempt.releaseTag) ?: attempt).copy(
                    workflowRunId = currentRun.runId,
                    status = status,
                    completedAt = if (currentRun.status == "completed") System.currentTimeMillis() else null,
                    message = currentRun.currentStep ?: currentRun.conclusion ?: currentRun.status
                )
                dao.upsertProject(storedProject)
                dao.upsertAttempt(storedAttempt)
                _state.update {
                    val mapped = progressFor(currentRun)
                    it.copy(activeProject = storedProject, workflowUrl = currentRun.runUrl, progress = mapped.first, progressLabel = mapped.second,
                        message = buildString {
                            append("GitHub Actions status: ${currentRun.status}")
                            currentRun.currentStep?.let { step -> append("\nCurrent workflow step: $step") }
                            if (currentRun.status == "completed") append("\nConclusion: ${currentRun.conclusion ?: "unknown"}")
                        }, isError = false)
                }
                if (currentRun.status == "completed") {
                    val logs = downloadDiagnosticsAndLogs(client, currentRun, attempt.releaseTag, project)
                    val completed = finishAttempt(client, storedProject, storedAttempt, currentRun, logs)
                    _state.update { it.copy(monitoringTag = null) }
                    return AttemptResult(completed, logs, currentRun)
                }
            } else {
                _state.update { it.copy(progress = 0.25f, progressLabel = "Waiting for the matching Release workflow", message = "No matching run is visible yet for ${attempt.releaseTag}. Checking again with backoff.", isError = false) }
            }
            delay(delayMs)
            delayMs = min((delayMs * 1.35).toLong(), 15_000L)
        }
        val latest = (dao.getProject(project.id) ?: project).copy(currentStatus = "MONITORING_TIMEOUT", lastMessage = "Monitoring timeout; remote job may continue")
        _state.update { it.copy(monitoringTag = null) }
        dao.upsertProject(latest)
        _state.update { it.copy(activeProject = latest, progressLabel = "Monitoring timeout", message = "Monitoring timed out. The remote build may still continue. Tap Refresh Build Status; do not publish another build just because monitoring timed out.", isError = true) }
        return AttemptResult(false, _state.value.logs, run)
    }

    private suspend fun finishAttempt(
        client: GitHubClient,
        project: ProjectEntity,
        attempt: BuildAttemptEntity,
        run: WorkflowRunState,
        logs: String
    ): Boolean {
        if (run.conclusion == "success") {
            val artifacts = client.getArtifacts(run.runId)
            val apkBundle = artifacts.firstOrNull { it.name == "apk-output-${attempt.releaseTag}" && !it.expired }
            if (apkBundle == null) {
                val failed = project.copy(currentStatus = "FAILED", lastMessage = "Workflow succeeded but the expected APK artifact is missing or expired.", workflowRunId = run.runId, diagnosticsPath = findDiagnosticsPath(project, attempt.releaseTag))
                dao.upsertProject(failed)
                dao.upsertAttempt(attempt.copy(status = "FAILED", completedAt = System.currentTimeMillis(), message = failed.lastMessage, diagnosticsPath = failed.diagnosticsPath))
                _state.update { it.copy(activeProject = failed, logs = logs, message = failed.lastMessage ?: "APK artifact unavailable", progress = 0.92f, progressLabel = "Artifact unavailable", isError = true) }
                return false
            }
            val workspace = File(project.workspacePath, "artifacts/${attempt.releaseTag}")
            val archive = File(project.workspacePath, "downloads/${attempt.releaseTag}-artifact.zip")
            client.downloadArtifact(apkBundle.id, archive)
            val apks = withContext(Dispatchers.IO) { artifactProcessor.extractArtifactBundle(archive, workspace) }
            val first = apks.firstOrNull()
            val statusProject = project.copy(
                currentStatus = "SUCCEEDED",
                workflowRunId = run.runId,
                apkPath = first?.file?.absolutePath,
                apkSha256 = first?.sha256,
                diagnosticsPath = findDiagnosticsPath(project, attempt.releaseTag),
                lastMessage = "GitHub Actions completed successfully; ${apks.size} validated APK file(s) are available."
            )
            dao.upsertProject(statusProject)
            dao.upsertAttempt(attempt.copy(status = "SUCCEEDED", completedAt = System.currentTimeMillis(), artifactId = apkBundle.id, apkPath = first?.file?.absolutePath, diagnosticsPath = statusProject.diagnosticsPath, message = statusProject.lastMessage))
            removePendingTag(attempt.releaseTag)
            _state.update { it.copy(activeProject = statusProject, apks = apks, selectedApkIndex = 0, logs = logs, progress = 1f, progressLabel = "APK downloaded and verified", message = "Build succeeded. ${apks.size} APK file(s) extracted; SHA-256 and APK manifest entry verified. This is not a Play Store readiness guarantee.", isError = false, screen = BuilderScreen.DOWNLOADS) }
            return true
        }
        val failed = project.copy(currentStatus = "FAILED", workflowRunId = run.runId, diagnosticsPath = findDiagnosticsPath(project, attempt.releaseTag), lastMessage = "GitHub Actions concluded ${run.conclusion ?: "without a successful build"}.")
        dao.upsertProject(failed)
        dao.upsertAttempt(attempt.copy(status = "FAILED", completedAt = System.currentTimeMillis(), diagnosticsPath = failed.diagnosticsPath, message = failed.lastMessage))
        removePendingTag(attempt.releaseTag)
        _state.update { it.copy(activeProject = failed, logs = logs.ifBlank { "Workflow failed but diagnostic logs could not be retrieved. Open the GitHub run for logs.\n${run.runUrl}" }, progress = 1f, progressLabel = "Build failed", message = "Build failed on GitHub Actions. The original project remains unchanged. Review the log and ask Gemini for a diagnosis.", isError = true, screen = BuilderScreen.LOGS) }
        return false
    }

    private suspend fun downloadDiagnosticsAndLogs(client: GitHubClient, run: WorkflowRunState, tag: String, project: ProjectEntity): String {
        var output = ""
        try {
            val bundle = client.getArtifacts(run.runId).firstOrNull { it.name == "build-diagnostics-$tag" && !it.expired }
            if (bundle != null) {
                val archive = File(project.workspacePath, "downloads/diagnostics-$tag.zip")
                client.downloadArtifact(bundle.id, archive)
                val directory = File(project.workspacePath, "diagnostics/$tag")
                val files = withContext(Dispatchers.IO) { artifactProcessor.extractZipContents(archive, directory) }
                output = files.firstOrNull { it.name == "build.log" }?.readText(Charsets.UTF_8).orEmpty()
                if (output.isBlank()) output = files.firstOrNull { it.name == "build-result.json" }?.readText(Charsets.UTF_8).orEmpty()
                if (output.isNotBlank()) dao.getAttemptByTag(tag)?.let { dao.upsertAttempt(it.copy(diagnosticsPath = directory.absolutePath)) }
            }
        } catch (error: Exception) {
            output = "Could not retrieve diagnostic artifact: ${Redactor.redact(error.message ?: error.javaClass.simpleName)}\n"
        }
        if (output.isBlank()) {
            try {
                val logArchive = File(project.workspacePath, "downloads/workflow-logs-$tag.zip")
                client.downloadRunLogs(run.runId, logArchive)
                val directory = File(project.workspacePath, "diagnostics/$tag-run-logs")
                val files = withContext(Dispatchers.IO) { artifactProcessor.extractZipContents(logArchive, directory) }
                output = files.filter { it.extension.equals("txt", true) || it.name.contains("log", true) }
                    .take(8).joinToString("\n\n--- workflow log file ---\n\n") { it.readText(Charsets.UTF_8).takeLast(60_000) }
            } catch (error: Exception) {
                output += "\nWorkflow logs not available: ${Redactor.redact(error.message ?: error.javaClass.simpleName)}"
            }
        }
        return Redactor.redact(output).takeLast(200_000)
    }

    private suspend fun tryAutomaticRepair(projectId: String, failedTag: String, logs: String, attemptNumber: Int, repairDepth: Int): Boolean {
        val project = dao.getProject(projectId) ?: return false
        if (logs.isBlank()) {
            _state.update { it.copy(message = "Auto Fix stopped: no build logs were retrieved.", isError = true) }
            return false
        }
        if (secrets.get(GeminiClient.SECRET_GEMINI_KEY).isNullOrBlank()) {
            _state.update { it.copy(message = "Build failed. Auto Fix needs a tested Gemini key; open Gemini Settings or use manual repair.", isError = true) }
            return false
        }
        val model = prefs.getString(KEY_GEMINI_MODEL, DEFAULT_GEMINI_MODEL) ?: DEFAULT_GEMINI_MODEL
        try {
            _state.update { it.copy(progressLabel = "Gemini diagnosis", message = "Automatic repair attempt ${repairDepth + 1}/$MAX_REPAIR_ATTEMPTS: sending redacted logs and user-consented source snippets to Gemini…", isError = false) }
            val source = withContext(Dispatchers.IO) { collectSourceContext(File(project.projectRootPath), logs) }
            val diagnosis = GeminiClient(context).diagnoseBuildFailure(model, logs, source, sourceWasConsented = true)
            val validated = patchValidator.validate(diagnosis, File(project.projectRootPath))
            _state.update { it.copy(repairDiagnosis = diagnosis, repairProposal = validated, repairValidationError = null, repairPreview = buildRepairPreview(File(project.projectRootPath), validated), screen = BuilderScreen.AI_FIXER) }
            if (!validated.isLowRiskAutoEligible || validated.changes.isEmpty()) {
                _state.update { it.copy(message = "Auto Fix did not apply this proposal: it is empty or requires approval. Review the proposal in AI Error Fixer.", isError = true) }
                return false
            }
            val backup = File(project.workspacePath, "repair-history/${System.currentTimeMillis()}-before-repair").apply { mkdirs() }
            withContext(Dispatchers.IO) { copyDirectory(File(project.projectRootPath), backup) }
            val changed = withContext(Dispatchers.IO) { patchValidator.apply(validated, File(project.projectRootPath)) }
            val updated = project.copy(repairAttempts = project.repairAttempts + 1, currentStatus = "REPAIR_APPLIED", lastMessage = "Auto-applied low-risk patch: ${changed.joinToString()}")
            dao.upsertProject(updated)
            dao.getAttemptByTag(failedTag)?.let { dao.upsertAttempt(it.copy(changedFilesJson = JSONArray(changed).toString(), message = "Failed; low-risk AI patch applied to a separate working copy")) }
            val newReport = withContext(Dispatchers.IO) {
                processor.createCleanSourceZip(File(updated.projectRootPath), File(updated.workspacePath, "outgoing/source-repair-${updated.repairAttempts}-${System.currentTimeMillis()}.zip"))
            }
            _state.update { it.copy(activeProject = updated, repairFilesApplied = changed, packagingReport = null, progressLabel = "Rebuilding repaired project", message = "Applied eligible low-risk patch to the working copy: ${changed.joinToString()}. Starting a new uniquely tagged build attempt.", isError = false) }
            val nextAttempt = (dao.getAttemptsForProject(projectId).maxOfOrNull { it.attemptNumber } ?: attemptNumber) + 1
            // Bounded recursive loop: repairDepth is checked before entering and grows once per repair.
            performBuildAttempt(updated, newReport, nextAttempt, repairDepth + 1)
            return true
        } catch (error: CancellationException) { throw error }
        catch (error: Exception) {
            _state.update { it.copy(repairValidationError = error.message, message = "Auto Fix stopped safely: ${error.message ?: error.javaClass.simpleName}", isError = true, screen = BuilderScreen.AI_FIXER) }
            return false
        }
    }

    fun refreshBuildStatus(silent: Boolean = false) {
        val project = _state.value.activeProject ?: run { if (!silent) showError("Open a project with a known build tag first."); return }
        val tag = project.releaseTag ?: run { if (!silent) showError("This project does not have a remote Release tag yet."); return }
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, progressLabel = "Refreshing remote build", message = "Checking GitHub for the exact build tag $tag…", isError = false) }
            try {
                val client = GitHubClient(context, currentGitHubSettings())
                val run = if (project.workflowRunId != null) client.getWorkflowRun(project.workflowRunId) else client.findWorkflowRun(tag)
                if (run == null) {
                    _state.update { it.copy(message = "No matching GitHub Actions run is visible yet. The release may still be queued; try refreshing later.", isError = false) }
                } else {
                    val attempt = dao.getAttemptByTag(tag) ?: BuildAttemptEntity(UUID.randomUUID().toString(), project.id, 1, tag, project.releaseId, startedAt = project.lastBuildAt ?: System.currentTimeMillis())
                    val logs = if (run.status == "completed") downloadDiagnosticsAndLogs(client, run, tag, project) else _state.value.logs
                    finishAttempt(client, project.copy(workflowRunId = run.runId), attempt.copy(workflowRunId = run.runId), run, logs)
                }
            } catch (error: Exception) { if (!silent) showError("Could not refresh remote status: ${error.message}") }
            finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun stopMonitoring() {
        _state.value.monitoringTag?.let { stoppedMonitorTags.add(it) }
        _state.update { it.copy(message = "Monitoring stopped in this app. The GitHub workflow was not cancelled; use Cancel Remote Build to stop it.", isError = false) }
    }

    fun cancelRemoteBuild() {
        val project = _state.value.activeProject ?: return
        val runId = project.workflowRunId ?: run { showError("No workflow run ID is available yet."); return }
        viewModelScope.launch {
            try {
                GitHubClient(context, currentGitHubSettings()).cancelWorkflowRun(runId)
                _state.update { it.copy(message = "GitHub accepted the cancellation request. Refresh to verify the final status.", isError = false) }
            } catch (error: Exception) { showError("Could not cancel GitHub run: ${error.message}") }
        }
    }

    fun testGitHubConnection(token: String, owner: String, repository: String, branch: String) {
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, githubStatus = "Testing…", message = "Testing the token and checking the configured repository's privacy and push permissions…", isError = false) }
            try {
                val settings = GitHubSettings(owner.trim(), repository.trim(), branch.trim().ifBlank { "main" }).also { it.validate() }
                val client = GitHubClient(context, settings, token.trim())
                val connection = client.testConnection()
                if (!connection.isPrivate) throw IOException("Repository must be private.")
                if (!connection.canPush) throw IOException("Connection works, but push access is missing. Enable minimum Contents write and Workflows write permissions.")
                secrets.put(GitHubClient.SECRET_GITHUB_TOKEN, token.trim())
                prefs.edit().putString(BuildStatusWorker.KEY_OWNER, owner.trim())
                    .putString(BuildStatusWorker.KEY_REPO, repository.trim())
                    .putString(BuildStatusWorker.KEY_BRANCH, connection.defaultBranch.ifBlank { branch.trim().ifBlank { "main" } })
                    .apply()
                _state.update { it.copy(githubStatus = "Verified · private repository · push permission", message = "Connected as @${connection.login}. Repository ${connection.repoFullName} is private. Default branch: ${connection.defaultBranch}. API rate limit remaining: ${connection.remainingRateLimit ?: "unknown"}.", isError = false) }
            } catch (error: Exception) {
                _state.update { it.copy(githubStatus = "Test failed", message = "GitHub connection test failed: ${error.message ?: error.javaClass.simpleName}", isError = true) }
            } finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun removeGitHubCredentials() {
        secrets.remove(GitHubClient.SECRET_GITHUB_TOKEN)
        prefs.edit().remove(BuildStatusWorker.KEY_OWNER).remove(BuildStatusWorker.KEY_REPO).remove(BuildStatusWorker.KEY_BRANCH).apply()
        _state.update { it.copy(githubStatus = "Not configured", message = "GitHub token and repository settings removed from this device.", isError = false) }
    }

    fun dismissWorkflowOverwrite() {
        _state.update { it.copy(workflowOverwriteNeeded = false, isError = false) }
    }

    fun installWorkflow(overwriteDifferent: Boolean = false) {
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = "Verifying repository and installing the bundled workflow…", isError = false, workflowOverwriteNeeded = false) }
            try {
                val workflow = context.assets.open("templates/build-apk.yml").bufferedReader(Charsets.UTF_8).use { it.readText() }
                val client = GitHubClient(context, currentGitHubSettings())
                val response = client.installOrVerifyWorkflow(workflow, overwriteDifferent)
                val actions = runCatching { client.verifyActionsEnabled() }.getOrNull()
                _state.update { it.copy(message = "$response\nNext: verify GitHub Actions is enabled in repository settings. The workflow is triggered by published apkbuild-* Releases only.", isError = actions == false, workflowOverwriteNeeded = false, workflowInstalled = true, actionsEnabled = actions) }
            } catch (error: Exception) {
                if (error is com.aipkgbuilder.pro.github.WorkflowOverwriteRequired) {
                    _state.update { it.copy(message = "A different build-apk.yml exists. Compare it with the bundled workflow before replacing it. Tap 'Replace Workflow' only if you accept overwriting that file.", workflowOverwriteNeeded = true, isError = true) }
                } else showError("Workflow setup failed: ${error.message ?: error.javaClass.simpleName}. Fine-grained token may need Contents: write and Workflows: write.")
            } finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun retestSavedGitHubConnection() {
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, githubStatus = "Testing saved token…", isError = false) }
            try {
                val client = GitHubClient(context, currentGitHubSettings())
                val connection = client.testConnection()
                val permissions = client.verifyRepositoryPermissions()
                val actions = runCatching { client.verifyActionsEnabled() }.getOrNull()
                val workflow = client.workflowExists()
                _state.update { it.copy(githubStatus = "Verified · private repository · push permission", workflowInstalled = workflow, actionsEnabled = actions,
                    message = "Saved token verified as @${connection.login}.\n$permissions", isError = !connection.canPush || actions == false) }
            } catch (error: Exception) {
                _state.update { it.copy(githubStatus = "Test failed", message = "Saved GitHub settings could not be verified: ${error.message}", isError = true) }
            } finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun verifyGitHubActions() {
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = "Checking the real GitHub Actions permissions endpoint…", isError = false) }
            try {
                val client = GitHubClient(context, currentGitHubSettings())
                val enabled = client.verifyActionsEnabled()
                _state.update { it.copy(actionsEnabled = enabled, message = if (enabled) "GitHub Actions is enabled for the configured repository." else "GitHub Actions is disabled for this repository. Open Repository Settings → Actions → General and enable Actions.", isError = !enabled) }
            } catch (error: Exception) { showError("Could not verify GitHub Actions: ${error.message}. Check Actions: read permission on the fine-grained token.") }
            finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun verifyGitHubRepositoryPermissions() {
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = "Checking private visibility, push permission, workflow file and Actions availability…", isError = false) }
            try {
                val client = GitHubClient(context, currentGitHubSettings())
                val report = client.verifyRepositoryPermissions()
                val workflow = client.workflowExists()
                val actions = runCatching { client.verifyActionsEnabled() }.getOrNull()
                _state.update { it.copy(workflowInstalled = workflow, actionsEnabled = actions, message = report, isError = actions == false) }
            } catch (error: Exception) { showError("Repository permission check failed: ${error.message}") }
            finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun retestSavedGeminiConfiguration() {
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, geminiStatus = "Testing saved model…", isError = false) }
            try {
                val model = savedGeminiModel()
                val reply = GeminiClient(context).testKeyAndModel(model)
                _state.update { it.copy(geminiStatus = "Verified · $model", message = "Saved Gemini key/model passed a new live test. Response: ${Redactor.redact(reply).take(80)}", isError = false) }
            } catch (error: Exception) {
                _state.update { it.copy(geminiStatus = "Test failed", message = "Saved Gemini config test failed: ${error.message}", isError = true) }
            } finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun testAndSaveGeminiKey(apiKey: String, modelId: String) {
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, geminiStatus = "Testing…", message = "Sending a real Gemini API request. The key is sent in the x-goog-api-key header, never in the URL…", isError = false) }
            try {
                val trimmedKey = apiKey.trim()
                if (trimmedKey.isBlank()) throw GeminiApiException("INVALID_CREDENTIALS", null, "Enter a Gemini API key.")
                val response = GeminiClient(context, trimmedKey).testKeyAndModel(modelId.trim())
                secrets.put(GeminiClient.SECRET_GEMINI_KEY, trimmedKey)
                prefs.edit().putString(KEY_GEMINI_MODEL, modelId.trim()).putLong(KEY_GEMINI_TESTED_AT, System.currentTimeMillis()).apply()
                _state.update { it.copy(geminiStatus = "Verified · ${modelId.trim()}", message = "Genuine Gemini test succeeded for ${modelId.trim()}. Response: ${Redactor.redact(response).take(80)}. Key saved using Android Keystore-backed encryption.", isError = false) }
            } catch (error: Exception) {
                _state.update { it.copy(geminiStatus = "Test failed · ${error.message?.substringBefore(':') ?: error.javaClass.simpleName}", message = "Gemini test failed: ${error.message ?: error.javaClass.simpleName}. The new key/model was not activated.", isError = true) }
            } finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun fetchGeminiModels(apiKey: String) {
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = "Fetching the models that advertise generateContent support…", isError = false) }
            try {
                val models = GeminiClient(context, apiKey.trim()).listModels()
                _state.update { it.copy(geminiModels = models, message = "Loaded ${models.size} model(s) that advertise generateContent. Availability and quotas can still differ by account.", isError = false) }
            } catch (error: Exception) { showError("Could not fetch models: ${error.message}") }
            finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun removeGeminiKey() {
        secrets.remove(GeminiClient.SECRET_GEMINI_KEY)
        prefs.edit().remove(KEY_GEMINI_MODEL).remove(KEY_GEMINI_TESTED_AT).apply()
        _state.update { it.copy(geminiStatus = "Optional · not configured", geminiModels = emptyList(), repairDiagnosis = null, repairProposal = null, message = "Gemini API key removed. Ordinary GitHub builds can still run without AI.", isError = false) }
    }

    fun diagnoseCurrentFailure(shareSource: Boolean = _state.value.sourceConsent) {
        val project = _state.value.activeProject ?: run { showError("Open the failed project first."); return }
        val logs = _state.value.logs.takeIf { it.isNotBlank() && it != "No logs loaded yet." }
            ?: run { showError("No actual build logs are loaded. Refresh the failed build or open its GitHub run."); return }
        if (secrets.get(GeminiClient.SECRET_GEMINI_KEY).isNullOrBlank()) { showError("Configure and test a Gemini API key first. You can still build without AI."); return }
        aiRequestJob?.cancel()
        aiRequestJob = viewModelScope.launch {
            _state.update { it.copy(busy = true, aiRequestInProgress = true, screen = BuilderScreen.AI_FIXER, progressLabel = "Analyzing actual build logs", message = if (shareSource) "Sending redacted logs and selected source excerpts after your consent…" else "Sending redacted logs and minimal diagnostics only; source files will not be sent…", isError = false, repairDiagnosis = null, repairProposal = null, repairValidationError = null) }
            try {
                val source = if (shareSource) withContext(Dispatchers.IO) { collectSourceContext(File(project.projectRootPath), logs) } else ""
                val model = prefs.getString(KEY_GEMINI_MODEL, DEFAULT_GEMINI_MODEL) ?: DEFAULT_GEMINI_MODEL
                val diagnosis = GeminiClient(context).diagnoseBuildFailure(model, logs, source, sourceWasConsented = shareSource)
                var proposal: ValidatedRepair? = null
                var validationError: String? = null
                try { proposal = patchValidator.validate(diagnosis, File(project.projectRootPath)) }
                catch (error: Exception) { validationError = error.message }
                _state.update { it.copy(repairDiagnosis = diagnosis, repairProposal = proposal, repairValidationError = validationError,
                    repairPreview = proposal?.let { valid -> buildRepairPreview(File(project.projectRootPath), valid) }.orEmpty(), aiRequestInProgress = false, message = "Gemini diagnosis received from actual build evidence. Review the explanation and every proposed file change before applying anything.", isError = validationError != null) }
            } catch (error: Exception) { showError("Gemini diagnosis failed: ${error.message ?: error.javaClass.simpleName}") }
            finally { _state.update { it.copy(busy = false, aiRequestInProgress = false) } }
        }
    }

    fun stopAIRepair() {
        if (aiRequestJob?.isActive == true) aiRequestJob?.cancel()
        _state.update { it.copy(message = "AI request cancelled locally. If the remote request was already received, cancellation cannot retract data already sent.", isError = false, aiRequestInProgress = false) }
    }

    fun applyApprovedRepair() {
        val repair = _state.value.repairProposal ?: run { showError(_state.value.repairValidationError ?: "There is no validated patch to apply."); return }
        val project = _state.value.activeProject ?: run { showError("Open the project before applying the patch."); return }
        if (repair.changes.isEmpty()) { showError("Gemini proposed no file changes. Review the diagnosis and follow its manual steps."); return }
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, progressLabel = "Backing up before patch", message = "Creating a local backup of the working copy before applying the reviewed patch…", isError = false) }
            try {
                val root = File(project.projectRootPath)
                val backup = File(project.workspacePath, "repair-history/${System.currentTimeMillis()}-before-repair")
                withContext(Dispatchers.IO) { copyDirectory(root, backup) }
                val changed = withContext(Dispatchers.IO) { patchValidator.apply(repair, root) }
                val historyFile = File(project.workspacePath, "repair-history/${System.currentTimeMillis()}-proposal.json")
                historyFile.parentFile?.mkdirs()
                historyFile.writeText(repair.diagnosis.rawJson, Charsets.UTF_8)
                val updated = project.copy(repairAttempts = project.repairAttempts + 1, currentStatus = "REPAIR_APPLIED", lastMessage = "User-approved patch applied: ${changed.joinToString()}")
                dao.upsertProject(updated)
                project.releaseTag?.let { tag -> dao.getAttemptByTag(tag)?.let { dao.upsertAttempt(it.copy(changedFilesJson = JSONArray(changed).toString(), message = "User-approved patch applied to a separate working copy")) } }
                val report = withContext(Dispatchers.IO) {
                    processor.createCleanSourceZip(root, File(project.workspacePath, "outgoing/source-manual-repair-${System.currentTimeMillis()}.zip"))
                }
                _state.update { it.copy(activeProject = updated, repairFilesApplied = changed, packagingReport = report, progress = 1f,
                    progressLabel = "Repair applied · source package ready", message = "Patch applied only to the working copy; original ZIP and extracted source remain untouched. Changed files: ${changed.joinToString()}. Review excluded paths and tap Confirm & Upload to rebuild.", isError = false, screen = BuilderScreen.NEW_PROJECT) }
            } catch (error: Exception) { showError("Patch was not applied: ${error.message ?: error.javaClass.simpleName}") }
            finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun selectApk(index: Int) = _state.update { it.copy(selectedApkIndex = index.coerceIn(0, (it.apks.size - 1).coerceAtLeast(0))) }

    fun saveSelectedApk(destination: Uri) {
        val apk = _state.value.apks.getOrNull(_state.value.selectedApkIndex) ?: run { showError("No APK artifact is selected."); return }
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = "Saving APK through Android's document picker and verifying its SHA-256…", isError = false) }
            try {
                val hash = withContext(Dispatchers.IO) { artifactProcessor.saveApkToUri(context.contentResolver, apk, destination) }
                _state.update { it.copy(message = "APK saved and verified. Size ${humanSize(apk.sizeBytes)} · SHA-256 $hash", isError = false) }
            } catch (error: Exception) { showError("APK save failed: ${error.message}") }
            finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun exportLogs(destination: Uri) {
        val project = _state.value.activeProject
        val report = buildString {
            appendLine("AI APK Builder Pro diagnostic report")
            appendLine("Created: ${java.time.Instant.now()}")
            appendLine("Project: ${project?.name ?: "Not selected"}")
            appendLine("Build tag: ${project?.releaseTag ?: "None"}")
            appendLine("Workflow run ID: ${project?.workflowRunId ?: "Not available"}")
            appendLine("Status: ${project?.currentStatus ?: "Unknown"}")
            appendLine("Sensitive values have been redacted where detected.")
            appendLine()
            appendLine(Redactor.redact(_state.value.logs))
        }
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(destination, "w")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(report) } ?: throw IOException("Could not open target document.") }
                _state.update { it.copy(message = "Diagnostic report exported.", isError = false) }
            } catch (error: Exception) { showError("Could not export report: ${error.message}") }
        }
    }

    fun cleanTemporaryFiles() {
        if (_state.value.busy) return
        viewModelScope.launch {
            val project = _state.value.activeProject
            val keepOriginal = project?.originalZipPath
            val deleted = withContext(Dispatchers.IO) {
                var count = 0
                File(context.filesDir, "incoming").listFiles()?.forEach { if (it.delete()) count++ }
                project?.let {
                    listOf(File(it.workspacePath, "outgoing"), File(it.workspacePath, "downloads")).forEach { dir ->
                        if (dir.exists()) dir.listFiles()?.forEach { file -> if (file.absolutePath != keepOriginal && (file.deleteRecursively())) count++ }
                    }
                }
                count
            }
            _state.update { it.copy(storageBytes = context.filesDir.walkTopDown().filter { f -> f.isFile }.sumOf { f -> f.length() }, message = "Temporary ZIPs/downloads cleaned: $deleted item(s). Original project ZIP was not intentionally deleted.", isError = false) }
        }
    }

    fun deleteTemporaryRelease() {
        val project = _state.value.activeProject ?: return
        val releaseId = project.releaseId ?: run { showError("No temporary Release ID is known for this project."); return }
        val tag = project.releaseTag ?: return
        if (_state.value.busy) return
        viewModelScope.launch {
            _state.update { it.copy(busy = true, message = "Deleting temporary Release and tag after the build result has been captured…", isError = false) }
            try {
                val result = GitHubClient(context, currentGitHubSettings()).deleteTemporaryRelease(releaseId, tag)
                _state.update { it.copy(message = "$result\nLocal project and downloaded APK are preserved.", isError = false) }
            } catch (error: Exception) { showError("Release cleanup failed: ${error.message}") }
            finally { _state.update { it.copy(busy = false) } }
        }
    }

    fun copyText(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("AI APK Builder", text))
        _state.update { it.copy(message = "Copied to clipboard.", isError = false) }
    }

    fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (error: Exception) { showError("Could not open link: ${error.message}") }
    }

    private suspend fun restoreActiveProject() {
        val id = prefs.getString(KEY_ACTIVE_PROJECT_ID, null) ?: return
        val project = dao.getProject(id) ?: return
        runCatching {
            val root = File(project.projectRootPath)
            if (root.isDirectory) {
                val summary = withContext(Dispatchers.IO) { processor.analyzeExistingProjectRoot(root) }
                _state.update { it.copy(activeProject = project, summary = summary, selectedArchive = File(project.originalZipPath).takeIf { f -> f.isFile }?.let { f -> SelectedArchive(f, project.originalArchiveName, f.length()) }) }
            } else _state.update { it.copy(activeProject = project, message = "Saved workspace is missing. The original ZIP path was ${project.originalZipPath}.", isError = true) }
        }
    }

    private fun currentGitHubSettings(): GitHubSettings = GitHubSettings(
        prefs.getString(BuildStatusWorker.KEY_OWNER, "").orEmpty(),
        prefs.getString(BuildStatusWorker.KEY_REPO, "").orEmpty(),
        prefs.getString(BuildStatusWorker.KEY_BRANCH, "main").orEmpty()
    ).also { it.validate() }

    private fun addPendingTag(tag: String) {
        val tags = runtimePrefs.getStringSet("pending_release_tags", emptySet()).orEmpty().toMutableSet()
        tags += tag
        runtimePrefs.edit().putStringSet("pending_release_tags", tags).apply()
    }

    private fun removePendingTag(tag: String) {
        val tags = runtimePrefs.getStringSet("pending_release_tags", emptySet()).orEmpty().toMutableSet()
        tags.remove(tag)
        runtimePrefs.edit().putStringSet("pending_release_tags", tags).apply()
    }

    private fun scheduleBuildTracking() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = PeriodicWorkRequestBuilder<com.aipkgbuilder.pro.worker.BuildStatusWorker>(15, TimeUnit.MINUTES).setConstraints(constraints).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("github-build-status-polling", ExistingPeriodicWorkPolicy.KEEP, request)
    }

    private fun progressFor(run: WorkflowRunState): Pair<Float, String> {
        if (run.status == "queued" || run.status == "requested" || run.status == "waiting") return 0.28f to "GitHub Actions queued"
        if (run.status == "completed") return 0.94f to "Analyzing completed run"
        val step = run.currentStep.orEmpty()
        val label = when {
            "source" in step.lowercase() -> "Retrieving source ZIP"
            "project" in step.lowercase() || "extract" in step.lowercase() -> "Detecting project root"
            "java" in step.lowercase() -> "Setting up Java"
            "android sdk" in step.lowercase() || "environment" in step.lowercase() -> "Checking Android SDK"
            "gradle" in step.lowercase() -> "Running Gradle build"
            "apk" in step.lowercase() || "collect" in step.lowercase() -> "Collecting APK outputs"
            "diagnostic" in step.lowercase() -> "Preparing diagnostics"
            "upload" in step.lowercase() -> "Uploading workflow artifacts"
            else -> step.ifBlank { "Workflow in progress" }
        }
        val done = run.steps.count { it.status == "completed" }
        val total = run.steps.size.coerceAtLeast(1)
        return (0.30f + (0.55f * done / total)).coerceIn(0.30f, 0.89f) to label
    }

    private fun buildTag(projectId: String, attempt: Int): String = "apkbuild-${System.currentTimeMillis()}-${projectId.replace("-", "").take(8)}-attempt-$attempt"

    private fun findDiagnosticsPath(project: ProjectEntity, tag: String): String? = File(project.workspacePath, "diagnostics/$tag").takeIf { it.exists() }?.absolutePath

    private fun collectSourceContext(root: File, logs: String): String {
        val targets = linkedSetOf<File>()
        val mentioned = Regex("(?:[A-Za-z0-9_./-]+)\\.(?:kt|java|xml|gradle|kts|properties)").findAll(logs).map { it.value.trimStart('/', '.') }.take(40).toList()
        mentioned.forEach { path ->
            val clean = path.replace('\\', '/').split('/').filter { it.isNotBlank() && it != ".." }.joinToString(File.separator)
            val direct = File(root, clean)
            if (direct.isFile && direct.length() <= 32 * 1024) targets += direct
            else root.walkTopDown().maxDepth(12).firstOrNull { it.isFile && it.name == File(clean).name && it.length() <= 32 * 1024 }?.let { targets += it }
        }
        if (targets.isEmpty()) {
            listOf("build.gradle.kts", "build.gradle", "settings.gradle.kts", "settings.gradle", "gradle/libs.versions.toml").map { File(root, it) }.filter { it.isFile && it.length() <= 32 * 1024 }.forEach { targets += it }
        }
        val maxTotal = 24 * 1024
        val output = StringBuilder()
        for (file in targets.take(6)) {
            val text = runCatching { file.readText(Charsets.UTF_8) }.getOrDefault("")
            val rel = runCatching { root.toPath().relativize(file.toPath()).toString() }.getOrDefault(file.name)
            val chunk = "\n--- FILE: $rel ---\nSHA-256: ${processor.sha256(file)}\n${Redactor.redact(text).take(8_000)}\n"
            if (output.length + chunk.length > maxTotal) break
            output.append(chunk)
        }
        return output.toString()
    }

    private fun buildRepairPreview(root: File, repair: ValidatedRepair): String = buildString {
        repair.changes.forEach { change ->
            appendLine("FILE: ${change.path} (${change.operation})")
            appendLine("WHY: ${change.justification}")
            val old = if (change.operation == "UPDATE") runCatching { File(root, change.path).readText(Charsets.UTF_8) }.getOrDefault("[Cannot read original file]") else "[File will be created]"
            appendLine("--- BEFORE (first 2,000 characters) ---")
            appendLine(old.take(2_000))
            appendLine("--- AFTER (first 2,000 characters) ---")
            appendLine(change.content.take(2_000))
            appendLine()
        }
    }

    private fun copyDirectory(source: File, destination: File) {
        if (!source.isDirectory) throw IOException("Source project root is missing: $source")
        destination.mkdirs()
        source.walkTopDown().forEach { item ->
            val relative = source.toPath().relativize(item.toPath()).toString()
            val target = if (relative.isBlank()) destination else File(destination, relative)
            if (item.isDirectory) target.mkdirs() else {
                target.parentFile?.mkdirs()
                item.inputStream().buffered().use { input -> target.outputStream().buffered().use { input.copyTo(it, 64 * 1024) } }
            }
        }
    }

    private fun humanSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024L * 1024 -> "%.1f KB".format(bytes / 1024.0)
        bytes < 1024L * 1024 * 1024 -> "%.1f MB".format(bytes / (1024.0 * 1024))
        else -> "%.2f GB".format(bytes / (1024.0 * 1024 * 1024))
    }

    private fun showError(message: String) = _state.update { it.copy(message = Redactor.redact(message), isError = true, progressLabel = "Action failed") }

    companion object {
        const val PREFS = "builder_settings"
        private const val RUNTIME_PREFS = "builder_runtime"
        private const val KEY_ACTIVE_PROJECT_ID = "active_project_id"
        private const val KEY_GEMINI_MODEL = "gemini_model_id"
        private const val KEY_GEMINI_TESTED_AT = "gemini_last_tested_at"
        private const val KEY_AUTO_FIX = "auto_fix_mode"
        const val DEFAULT_GEMINI_MODEL = "gemini-3.8-flash"
        const val MAX_REPAIR_ATTEMPTS = 3
    }
}
