package com.aipkgbuilder.pro.github

import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class GitHubResponseParsingTest {
    @Test fun parsesExactWorkflowRunFields() {
        val json = JSONObject()
            .put("id", 123456L).put("status", "completed").put("conclusion", "success")
            .put("html_url", "https://github.com/example/builder/actions/runs/123456")
            .put("display_title", "APK build apkbuild-abc123-attempt-1")
            .put("created_at", "2026-10-16T05:00:00Z")
        val parsed = WorkflowRunParser.parse(json)
        assertEquals(123456L, parsed.runId)
        assertEquals("completed", parsed.status)
        assertEquals("success", parsed.conclusion)
        assertTrue(parsed.displayTitle.contains("apkbuild-abc123-attempt-1"))
        assertEquals("SUCCEEDED", BuildStateMapper.fromRemote(parsed.status, parsed.conclusion))
    }

    @Test fun unknownOrQueuedRunsDoNotAppearSuccessful() {
        assertEquals("IN_PROGRESS", BuildStateMapper.fromRemote("queued", null))
        assertEquals("FAILED", BuildStateMapper.fromRemote("completed", "failure"))
        assertEquals("FAILED", BuildStateMapper.fromRemote("completed", null))
        val parsed = WorkflowRunParser.parse(JSONObject().put("id", 9).put("status", "queued"))
        assertEquals("APK build", parsed.displayTitle)
        assertNull(parsed.conclusion)
    }
}
